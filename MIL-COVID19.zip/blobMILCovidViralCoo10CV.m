% We assume that each image contains the same number of pixels
% An image represents a bag
% Each blob is a features vector and represents an instance of the bag

clear;

% number of postive bags (positive images)
% number of negative bags (negative images) 

posBag = 100;
negBag = 100;

imgs = [
 %Malati
 'COVID (1)  ';'COVID (2)  '; 'COVID (3)  '; 'COVID (4)  '; 'COVID (5)  ';
 'COVID (6)  ';'COVID (7)  '; 'COVID (8)  '; 'COVID (9)  '; 'COVID (10) ';
 'COVID (11) ';'COVID (12) '; 'COVID (13) '; 'COVID (14) '; 'COVID (15) ';
 'COVID (16) ';'COVID (17) '; 'COVID (18) '; 'COVID (19) '; 'COVID (20) ';
 'COVID (21) ';'COVID (22) '; 'COVID (23) '; 'COVID (24) '; 'COVID (25) ';
 'COVID (26) ';'COVID (27) '; 'COVID (28) '; 'COVID (29) '; 'COVID (30) ';
 'COVID (31) ';'COVID (32) '; 'COVID (33) '; 'COVID (34) '; 'COVID (35) ';
 'COVID (36) ';'COVID (37) '; 'COVID (38) '; 'COVID (39) '; 'COVID (40) ';
 'COVID (41) ';'COVID (42) '; 'COVID (43) '; 'COVID (44) '; 'COVID (45) ';
 'COVID (46) ';'COVID (47) '; 'COVID (48) '; 'COVID (49) '; 'COVID (50) ';
 'COVID (51) ';'COVID (52) '; 'COVID (53) '; 'COVID (54) '; 'COVID (55) ';
 'COVID (56) ';'COVID (57) '; 'COVID (58) '; 'COVID (59) '; 'COVID (60) ';
 'COVID (61) ';'COVID (62) '; 'COVID (63) '; 'COVID (64) '; 'COVID (65) ';
 'COVID (66) ';'COVID (67) '; 'COVID (68) '; 'COVID (69) '; 'COVID (70) ';
 'COVID (71) ';'COVID (72) '; 'COVID (73) '; 'COVID (74) '; 'COVID (75) ';
 'COVID (76) ';'COVID (77) '; 'COVID (78) '; 'COVID (79) '; 'COVID (80) ';
 'COVID (81) ';'COVID (82) '; 'COVID (83) '; 'COVID (84) '; 'COVID (85) ';
 'COVID (86) ';'COVID (87) '; 'COVID (88) '; 'COVID (89) '; 'COVID (90) ';
 'COVID (91) ';'COVID (92) '; 'COVID (93) '; 'COVID (94) '; 'COVID (95) ';
 'COVID (96) ';'COVID (97) '; 'COVID (98) '; 'COVID (99) '; 'COVID (100)';
        
        %Sani
 'VIRAL (1)  ';'VIRAL (2)  '; 'VIRAL (3)  '; 'VIRAL (4)  '; 'VIRAL (5)  ';
 'VIRAL (6)  ';'VIRAL (7)  '; 'VIRAL (8)  '; 'VIRAL (9)  '; 'VIRAL (10) ';
 'VIRAL (11) ';'VIRAL (12) '; 'VIRAL (13) '; 'VIRAL (14) '; 'VIRAL (15) ';
 'VIRAL (16) ';'VIRAL (17) '; 'VIRAL (18) '; 'VIRAL (19) '; 'VIRAL (20) ';
 'VIRAL (21) ';'VIRAL (22) '; 'VIRAL (23) '; 'VIRAL (24) '; 'VIRAL (25) ';
 'VIRAL (26) ';'VIRAL (27) '; 'VIRAL (28) '; 'VIRAL (29) '; 'VIRAL (30) ';
 'VIRAL (31) ';'VIRAL (32) '; 'VIRAL (33) '; 'VIRAL (34) '; 'VIRAL (35) ';
 'VIRAL (36) ';'VIRAL (37) '; 'VIRAL (38) '; 'VIRAL (39) '; 'VIRAL (40) ';
 'VIRAL (41) ';'VIRAL (42) '; 'VIRAL (43) '; 'VIRAL (44) '; 'VIRAL (45) ';
 'VIRAL (46) ';'VIRAL (47) '; 'VIRAL (48) '; 'VIRAL (49) '; 'VIRAL (50) ';
 'VIRAL (51) ';'VIRAL (52) '; 'VIRAL (53) '; 'VIRAL (54) '; 'VIRAL (55) ';
 'VIRAL (56) ';'VIRAL (57) '; 'VIRAL (58) '; 'VIRAL (59) '; 'VIRAL (60) ';
 'VIRAL (61) ';'VIRAL (62) '; 'VIRAL (63) '; 'VIRAL (64) '; 'VIRAL (65) ';
 'VIRAL (66) ';'VIRAL (67) '; 'VIRAL (68) '; 'VIRAL (69) '; 'VIRAL (70) ';
 'VIRAL (71) ';'VIRAL (72) '; 'VIRAL (73) '; 'VIRAL (74) '; 'VIRAL (75) ';
 'VIRAL (76) ';'VIRAL (77) '; 'VIRAL (78) '; 'VIRAL (79) '; 'VIRAL (80) ';
 'VIRAL (81) ';'VIRAL (82) '; 'VIRAL (83) '; 'VIRAL (84) '; 'VIRAL (85) ';
 'VIRAL (86) ';'VIRAL (87) '; 'VIRAL (88) '; 'VIRAL (89) '; 'VIRAL (90) ';
 'VIRAL (91) ';'VIRAL (92) '; 'VIRAL (93) '; 'VIRAL (94) '; 'VIRAL (95) ';
 'VIRAL (96) ';'VIRAL (97) '; 'VIRAL (98) '; 'VIRAL (99) '; 'VIRAL (100)';
         ];

% edgeBlob is the edge of the blob;
% it must be a submultiple of 128

%edgeBlob = 16;
edgeBlob = 32;

% stepsize is the size of the step in catching the pixels inside the blobs
stepsize = 32;
%stepsize = 4;

% dimension of the blob, i.e the number of pixel inside each blob
dimBlob = edgeBlob*edgeBlob;

% total number of images (bags)
numImages = posBag + negBag;

% NOTE THAT IN imgs ALL THE FILE NAMES MUST CONTAIN THE SAME NUMBER OF
% CHARACTERS USING EVENTUAL BLANKS
   
imgs = cellstr(imgs);
numLevels = 3;
numFeatures = 10+numLevels*numLevels;

for kk = 1: numImages;
    
    iname = char(imgs(kk));
    
    % converting the image in a numeric format
    
    %[IMM, map] = imread(['im/' iname '.bmp']);   
    [IMM, map] = imread(['Images/' iname '.jpg']); 
    IMM = double(IMM);
    IMM = IMM(:,:,1);
    if ~isempty(map)
        IMM = ind2rgb(IMM,map);
    end
    [row,col] = size(IMM);

    % T contains the current features vector (blob)
    T=zeros(10,1);
    
    %dimBlob = 1024;

    % pixelRow is the number of pixel for each row (or column), obtained 
    % by eliminating the frames
    pixelRow = row - 2*edgeBlob;
    
    % NBE is the number of blobs for each image
    NBE = ((pixelRow-edgeBlob)/stepsize +1) * ((pixelRow-edgeBlob)/stepsize +1);

    % X is the matrix whose the rows contain the feature vectors  
    X = zeros(NBE,numFeatures);

    % i and j are the position of the most left-upper pixel in the blob
    t=1;
    countBlob = 0;
    for i = edgeBlob+1 : stepsize : (row-2*edgeBlob+1)
        for j = edgeBlob+1 : stepsize : (col-2*edgeBlob+1)
            countBlob = countBlob + 1; 
            % average of the central blob
            for m = 1:1
                M = [];
                i1 = i+edgeBlob-1;
                j1 = j+edgeBlob-1;
                for k = i:i1
                    M = [M, IMM(k,j:j1)];
                    %glcm = graycomatrix(IMM(k,j:j1),'NumLevels',4,'GrayLimits', [])
                    %glcm = reshape(glcm,[1,9]);
                end
                glcm = graycomatrix(M,'NumLevels',numLevels,'GrayLimits', []);
                B1 = mean(M);
                B2 = var(M);
                T(10*(m-1)+1) = B1;
                T(10*(m-1)+2) = B2;
                % average of the right blob
                M = [];
                j1 = j+edgeBlob;
                j2 = j+2*edgeBlob-1;
                for k = i:i1
                    M = [M, IMM(k,j1:j2)];
                end
                B1 = mean(M);  
                B2 = var(M);
                T(10*(m-1)+3) = T(10*(m-1)+1) - B1;
                T(10*(m-1)+4) = T(10*(m-1)+2) - B2;
                %T(2) = B1;
                % average of the left blob
                M = [];
                j1 = j-edgeBlob;
                j2 = j-1;
                for k = i:i1
                    M = [M, IMM(k,j1:j2)];
                end
                B1 = mean(M);   
                B2 = var(M);
                T(10*(m-1)+5) = T(10*(m-1)+1) - B1;
                T(10*(m-1)+6) = T(10*(m-1)+2) - B2;
                %T(3) = B1;
                % average of the upper blob
                M = [];
                i1 = i-edgeBlob;
                i2 = i-1;
                j1 = j+edgeBlob-1;
                for k = i1:i2
                    M = [M, IMM(k,j:j1)];
                end
                B1 = mean(M);     
                B2 = var(M);
                T(10*(m-1)+7) = T(10*(m-1)+1) - B1;
                T(10*(m-1)+8) = T(10*(m-1)+2) - B2;
                %T(4) = B1;
                % average of the lower blob
                M = [];
                i1 = i+edgeBlob;
                i2 = i+2*edgeBlob-1;
                j1 = j+edgeBlob-1;
                for k = i1:i2;
                    M = [M, IMM(k,j:j1)];
                end
                B1 = mean(M);  
                B2 = var(M);
                T(10*(m-1)+9) = T(10*(m-1)+1) - B1;
                T(10*(m-1)+10) = T(10*(m-1)+2) - B2;
            end
            X(t,1:10) = T;
            X(t,11:numFeatures) = reshape(glcm,[1,numLevels*numLevels]);
            t=t+1;
        end
    end
    
   % the 'features' matrix contains in its row all the features vector (instances-blobs) 
  
   %if (kk==1) 
   %    features = zeros(NBE*numImages,15);
   %end
   init = 1 + NBE *(kk-1); 
   features(init:init+NBE-1,1:numFeatures)= X;

end

% bag_ids(i) = j if the instance i belongs to the bag j
bag_ids = zeros(1,NBE*numImages);

% labels(i) is equal to 1 if the instance i is positive and 
% it is equal to -1 if the instance i is negative

labels = zeros(1,NBE*numImages);
for k = 1 : numImages
    init = 1 + NBE *(k-1);
    for l = init : init + NBE -1
        bag_ids(l) = k;
        if (k <= posBag)
            labels(l) = 1;
        else
            labels(l) = -1;
        end
    end   
end

idxUnls = [];
idxLabs = [1:numImages];

%t indicates the number of fold in the CV cross validation
%idxLabs: training; idxUnls: testing

t = 10;
sm = numImages;
[idxLabs, idxUnls]=split_new(sm, t);


save Dataset/CovidViralCoo10CV bag_ids features labels idxLabs idxUnls;
