function [idxLabs, idxUnls]=split_new(sm, t);

rng(1);

% in MIL sm is the numer of bags;
% t is the number of fold

p = randperm(sm);

                               
indx_a = [0:t];                 
indx_a = floor(sm/t)*indx_a ;  %last row numbers for all 'segments'

% split trainining set from test set

idxLabs=zeros(t,sm-floor(sm/t));
idxUnls=zeros(t,floor(sm/t));
for i = 1:t
%    if (i==10)
%       ptest1=p(indx_a(i)+1+1:indx_a(i+1));
%    else
      ptest1=p(indx_a(i)+1:indx_a(i+1));
%   end
   idxUnls(i,:)=ptest1;
   
%    if (i==10)
%       ptrain1 = p(1:indx_a(i)); 
%       ptrain1 = [ptrain1 p(indx_a(i+1):sm)];
%    else
      ptrain1 = p(1:indx_a(i)); 
      ptrain1 = [ptrain1 p(indx_a(i+1)+1:sm)];
%   end
   idxLabs(i,:)=ptrain1;

end
return


