function [w, b] = RL_MIL(C,X,bags,bag_ids,labelsBag,output,summary)

% C is the model selection parameter
% X is the matrix of the points to learn the classifier
% bags is the array containing the bags used to lear the classifier
% bag_ids(i) is the bag to which point i belongs 
% labelsBag is the array of the labels of the all the bags of the dataset

% maxNumLagr is the number of Lagrangian problems to be solved

maxNumLagr = 5;

% maxNumIterBCD is the maximum number of iterations in BCD

maxNumIterBCD = 5;

% tolBCD is the optimality tolerance for BCD method

tolBCD = 1.e-3;

% numPoints is the number of points used to learn the classifier
% dim is the dimension of the space

[numPoints, dim] = size(X);

% numBags is the number of bags used to learn the classifier

[temp, numBags] = size(bags);

% numTotalBags is the number of bags of the entire dataset

[temp, numTotalBags] = size(labelsBag);

% lambda is the array of the multipliers: the initial value of lambda is 2*C;

lambda = zeros(1,numTotalBags);

for i=1:numBags  
    if labelsBag(bags(i))==1
        lambda(bags(i)) = 2 * C;
    end
end

% numPosPointsInBag(i) indicates the current number of positive points in bag i 

numPosPointsInBag = zeros(1,numTotalBags);

% y(i) is the unknown label of point i in a positive bag

for i=1:numPoints
    if labelsBag(bag_ids(i)) == 1
        y(i) = 1;
        numPosPointsInBag(bag_ids(i)) = numPosPointsInBag(bag_ids(i)) + 1;
    else
        y(i) = -1;
    end
end

% numLagr indicates the number of the current Lagrangian problem to be solved 

numLagr = 1;

% LB is the current lower bound
    
LB = -Inf;
    
% UB is the current upper bound
    
UB = Inf;

while numLagr <= maxNumLagr
    
    % numIterBDC indicates the number of current iteration of BDC

    numIterBCD = 1;
    
    % optBCD is true if the BCD has reached the optimality

    optBCD = false;
    
    % sumLambda is the sum of values of lambda

    sumLambda = sum(lambda);

    while optBCD == false 
        
        if numLagr > 1 && numIterBCD > maxNumIterBCD
            %fprintf('BCD TERMINATED: maximum number of iterations reached \n');
            fprintf(output,'BCD TERMINATED: maximum number of iterations reached \n');
            break;
        end

        % solving the SVM problem:
        % x is the otimal solution of SVM
        % fSVM is the optimal objective value SVM
        
        %[x,fSVM] = SVM(X,C,y);
       
        [x,fSVM] = DSVM(X,C,y,summary,output);
        
        
       
       
        
        if (numIterBCD >= 2)
            fLagrOld = fLagr;
        else
            fLagrOld = Inf;
        end
        
        % fLagr is the current value of the Lagrangian function
        
        fLagr = fSVM;

        for i=1:numBags
            if (labelsBag(bags(i)) == 1)
                fLagr = fLagr + lambda(bags(i)) * (1-numPosPointsInBag(bags(i)));
            end
        end
        
        if abs(fLagrOld-fLagr) <= tolBCD
            optBCD = true;
            %fprintf('BCD TERMINATED: OPTIMALITY reached \n')
            fprintf(output,'BCD TERMINATED: OPTIMALITY reached \n');
            
            if fLagr > LB
                LB = fLagr;
            end
            break;
        end

        %fprintf('LAGRANGIAN RELAXATION NUMBER %i ---> BCD number %i \n',numLagr, numIterBCD);
        %fprintf('SVM objective function: %12.8f; ',fSVM);
        %fprintf('sum of lambda: %12.8f; ',sum(lambda));
        %fprintf('LR objective function: %12.8f \n',fLagr);
        
        fprintf(output,'LAGRANGIAN RELAXATION NUMBER %i ---> BCD number %i \n',numLagr, numIterBCD);
        fprintf(output,'SVM objective function: %12.8f; ',fSVM);
        fprintf(output,'sum of lambda: %12.8f; ',sum(lambda));
        fprintf(output,'LR objective function: %12.8f \n',fLagr);

        w = x(1:dim);

        b = x(dim+1);

        % computing h

        h = X * w + b;

        % optimizing with respect to y

        yChanged = false;

        for i=1:numPoints

            if labelsBag(bag_ids(i)) == 1

                if h(i) <= -1

                    if (lambda(bag_ids(i)) > C * (1-h(i))) && (y(i) == -1)
                        y(i) = 1;
                        numPosPointsInBag(bag_ids(i)) = numPosPointsInBag(bag_ids(i)) + 1;
                        yChanged = true;
                    elseif (lambda(bag_ids(i)) <= C * (1-h(i))) && (y(i) == 1)
                        y(i) = -1;
                        numPosPointsInBag(bag_ids(i)) = numPosPointsInBag(bag_ids(i)) - 1;
                        yChanged = true;
                    end

                elseif h(i) >= 1

                    if y(i) == -1

                        y(i) = 1;
                        numPosPointsInBag(bag_ids(i)) = numPosPointsInBag(bag_ids(i)) + 1;
                        yChanged = true;

                    end

                elseif (lambda(bag_ids(i)) >= -2 * C * h(i)) && (y(i) == -1)

                    y(i) = 1;
                    numPosPointsInBag(bag_ids(i)) = numPosPointsInBag(bag_ids(i)) + 1;
                    yChanged = true;

                elseif (lambda(bag_ids(i)) < -2 * C * h(i)) && (y(i) == 1)

                    y(i) = -1;
                    numPosPointsInBag(bag_ids(i)) = numPosPointsInBag(bag_ids(i)) - 1;
                    yChanged = true;

                end

            end
        end

        if yChanged == false
            %fprintf('BCD TERMINATED: OPTIMALITY reached \n');
            fprintf(output,'BCD TERMINATED: OPTIMALITY reached \n');
            optBCD = true;
            if fLagr > LB
                LB = fLagr;
            end
            break;
        else
            % computing the new objective function fLagr
            
            fLagrOld = fLagr;
            
            fSVM = 0.5 * (w'*w);
            fLagr = fSVM + sumLambda;
            for i = 1:numPoints
                if labelsBag(bag_ids(i)) == -1
                    temp = 1 + h(i);
                else
                    temp = 1 - y(i) * h(i);
                    if y(i) == 1
                        fLagr = fLagr - lambda(bag_ids(i)); 
                    end
                end
                if temp > 0.0
                    fLagr = fLagr + C * temp;
                    fSVM = fSVM + C * temp;
                end
            end         
            
            %fprintf('Some labels have changed: LR objective function = %12.8f \n',fLagr);
            fprintf(output,'Some labels have changed: LR objective function = %12.8f \n',fLagr);
            
            if fLagr > fLagrOld
                fLagr = fLagrOld;
                %fprintf('BCD TERMINATED: OPTIMALITY reached (numerical errors) \n');
                fprintf(output,'BCD TERMINATED: OPTIMALITY reached (numerical errors) \n');
                optBCD = true;
                if fLagr > LB
                    LB = fLagr;
                end
                break;
            end
                    
        end
            
    numIterBCD = numIterBCD + 1; 

    % END OF "while (numIterBCD <= maxNumIterBCD && optBCD == false)"
    end     
    
    % Computing an upper bound
    
    [wFeasible, bFeasible, yFeasible, fFeasible] = ...
        upperBound(C,X,bag_ids,w,b,y,fSVM,h,bags,labelsBag,...
        numPosPointsInBag,output,summary);
    
    if fFeasible < UB
        UB = fFeasible;
        w = wFeasible;
        b = bFeasible;
    end
    if (optBCD == false)
        numIterBCD = numIterBCD -1;
    end
    fprintf('LB = %12.8f; UB = %12.8f; Number of BCD iterations = %i \n',LB, UB, numIterBCD);
    fprintf(output,'LB = %12.8f; UB = %12.8f; Number of BCD iterations = %i \n',LB, UB, numIterBCD);
    fprintf(summary,'LB = %12.8f; UB = %12.8f; Number of BCD iterations = %i \n',LB, UB, numIterBCD);
        
    if (numLagr == maxNumLagr)
        fprintf('Learning phase completed: maximum number of LR iterations reached \n');
        fprintf(summary,'Learning phase completed: maximum number of LR iterations reached \n');
        fprintf(output,'Learning phase completed: maximum number of LR iterations reached \n');
        break;
    end
    
    % g is the subgradient
    
    g = zeros(1,numTotalBags);
    
    for i=1:numBags
        if labelsBag(bags(i)) == 1
            g(bags(i)) = 1 - numPosPointsInBag(bags(i));
        end
    end
    
    % t is the stepsize;
    
    t = (UB-LB)/(g*g');
    
    numLagr = numLagr + 1; 
    
    lambda = max(0,lambda+t*g); 

% END OF "while numLagr <= maxNumLagr"  
end










        
  

