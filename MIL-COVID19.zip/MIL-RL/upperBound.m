function [wFeasible, bFeasible, yFeasible, fFeasible] = ...
    upperBound(C,X,bag_ids,w,b,y,f,h,bags,labelsBag,...
    numPosPointsInBag,output,summary)


% numPoints is the number of points used to learn the classifier
% dim is the dimension of the space

[numPoints, dim] = size(X);

% numBags is the number of bags used to learn the classifier

[temp, numBags] = size(bags);

feasible = true;
for i=1:numBags
    if labelsBag(bags(i)) == 1 && numPosPointsInBag(bags(i)) == 0
        feasible = false;
        break;
    end  
end

yFeasible = y;
if feasible == true
    %fprintf('Feasible solution \n');
    fprintf(output,'Feasible solution \n');
    wFeasible = w;
    bFeasible = b;
    fFeasible = f;
    return;
end

%fprintf('Unfeasible solution: ');
fprintf(output,'Unfeasible solution: ');

% numTotalBags is the number of bags of the entire dataset

[temp, numTotalBags] = size(labelsBag);

bagFound = zeros(1,numTotalBags);
deltaF = zeros(1,numTotalBags);
iMin = zeros(1,numTotalBags);

for i=1:numPoints   
    currentBag = bag_ids(i);
    if labelsBag(currentBag) == 1 && numPosPointsInBag(currentBag) == 0 
        if bagFound(currentBag) == false
            bagFound(currentBag) = true;
            if h(i) <= -1
                deltaF(currentBag) = C - C * h(i);
            elseif h(i) >= 1
                deltaF(currentBag) = - C - C * h(i);
            else
                deltaF(currentBag) = -2 * C * h(i);
            end
            iMin(currentBag) = i;
        else
            if h(i) <= -1
                deltaFTemp = C - C * h(i);
            elseif h(i) >= 1
                deltaFTemp = - C - C * h(i);
            else
                deltaFTemp = -2 * C * h(i);
            end
            if deltaFTemp < deltaF(currentBag)
                deltaF(currentBag) = deltaFTemp;
                iMin(currentBag) = i;
            end
        end  
    end
end

sumDeltaF = 0.0;
for i=1:numBags
    if numPosPointsInBag(bags(i)) == 0 && labelsBag(bags(i)) == 1
        yFeasible(iMin(bags(i))) = 1;
        sumDeltaF = sumDeltaF + deltaF(bags(i));
    end
end

%fprintf('DeltaLR = %12.8f; \n', sumDeltaF);
fprintf(output,'DeltaLR = %12.8f; \n', sumDeltaF);

%[x,fFeasible] = SVM(X,C,yFeasible);
[x,fFeasible] = DSVM(X,C,yFeasible);

wFeasible = x(1:dim);

bFeasible = x(dim+1);





