function [x,fval] = DSVM(X,C,y,output,summary)

% numPoints is the number of points used to learn the classifier
% dim is the dimension of the space

[numPoints, dim] = size(X);

numVar = numPoints;

% computing the SVM hyperplane

% A is the constraints matrix in SVM

A = y;

% b is the constraints right hand side vector 

b = 0.0;

% H is the quadratic term matrix of the objective function

H = zeros(numVar,numVar);

% PRIMA FORMA

% tic
% 
% for i = 1: numPoints
%     for j = 1: numPoints
%         H(i,j) = y(i)*y(j)*X(i,:)*X(j,:)';
%     end
%     A(1,i) = y(i);
% end
% 
% toc
%H1 = H;

% SECONDA FORMA

% tic
% 
% for i = 1: numVar
%     for j = i: numVar
%         H(i,j) = y(i)*y(j)*X(i,:)*X(j,:)';
%         if j ~= i
%             H(j,i) = H(i,j);
%         end
%     end
% end
% 
% toc
%H2 = H;

% TERZA FORMA

H = diag(y) * X;
H = H*H';

%H3 = H;

% assert(all(abs(H1(:) - H2(:)) < 1e-6 ));
% assert(all(abs(H1(:) - H3(:)) < 1e-6 ));

% f is the linear term in the objective function

f = -ones(numVar,1);

% l and u are the lower bounds and the upper bounds on the variables

ub = C*ones(numVar,1);

lb = zeros(numVar,1);

opts = optimoptions('quadprog','Display','off');

[mu,fvalDual] = quadprog(H,f,[],[],A,b,lb,ub,[],opts);

wStar = zeros(1,dim);

for i=1:numVar
    wStar = wStar + mu(i)*y(i)*X(i,:);
end

found = false;
for i=1:numVar
    %if (mu(i) > 1.e-10 && mu(i) < (C-1.e-10))
    if (mu(i) > 1.e-6 && mu(i) < (C-1.e-6))
        bStar = (1.0/y(i)) - wStar*X(i,:)';
        found = true;
        break;       
    end
end

if found == false
    fprintf('WARNING: denenerate solution \n');
    fprintf(summary,'WARNING: degenerate solution \n');
    fprintf(output,'WARNING: degenerate solution \n');
    bStar = -1.0;
end

x = [wStar bStar]';
fval = -fvalDual;



