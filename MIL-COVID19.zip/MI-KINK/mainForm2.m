for dataset=0:0
     if dataset == 0
        clear;
        results=fopen('res2/results-CovidViralCoo5CV.txt','w');
        output = fopen('res2/output-CovidViralCoo5CV.txt','w');
        summary = fopen('res2/summary-CovidViralCoo5CV.txt','w');
        load ../Dataset/CovidViralCoo5CV.mat;
        dataset = 0;
     elseif dataset == 1
        clear;
        results=fopen('res2/results-CovidViralCoo10CV.txt','w');
        output = fopen('res2/output-CovidViralCoo10CV.txt','w');
        summary = fopen('res2/summary-CovidViralCoo10CV.txt','w');
        load ../Dataset/CovidViralCoo10CV.mat;
        dataset = 1;
    end
    
    mode = 2;


% fprintf(output,'melanoma32325 \n\n');
% fprintf(summary,'melanoma32325 \n\n');
% fprintf(results,'melanoma32325 \n\n');

% X is the matrix containing in its rows the features%
X = full(features);

% labels(i) is the true label of point i
labels = full(labels);

% bag_ids(i) is the bag to which point i belongs
bag_ids = full(bag_ids);

% numTotalBags is the total number of bags
numTotalBags = max(bag_ids);

% numTotalPoints is the total number of points
% dim is the dimension of the space
[numTotalPoints, dim] = size(X);

% labelsBag(i) is the label of bag i
for i= 1: numTotalBags
    labelsBag(i) = -1;
end
for i=1:numTotalPoints
  if labels(i) == 1
      labelsBag(bag_ids(i)) = 1;
  end
end

% choosing the model selection type 
% mode = 0: no model selection, X = XTrain = Xtest, fix C;
%      = 1: no model selection, fix Xtrain, fix Xtest, fix C;
%      = 2: model selection, fix numberFoldLev1 and numberFoldLev2
%           and the grid of C. In this case FoldLev1 may be fixed
%           also equal to 0.
% mode = 3: requires the input values of C (no model selection) to be put
%           in array bestC;



if mode == 0
    
    C = 0.1;
    
    idxLabs = [1:numTotalBags];
    
    [w, b] = Formulazione2(C,X,idxLabs,bag_ids,labelsBag,output,summary);
    %[w, b] = Heuristics(C,X,idxLabs,bag_ids,labelsBag,output,summary);
   
    print = true;
    correctnessPercentage = correctness(X,idxLabs,bag_ids,labelsBag,w,b,print,output,summary);
    
    fprintf('TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentage);
    
    fprintf(output,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentage);
    
end

if mode == 1
    
    C = 2^-7;
    
    % Xtrain is the matrix of the points of the training set 
    XTrain = [];
    
    % bag_idsTrainLev1 is the part of vector bag_ids corresponding to the training set
    bag_idsTrain = [];
    
    % XTest is the matrix of the points of the testing set 
    XTest = [];
    
    % bag_idsTest is the part of vector bag_ids corresponding to the testing set
    bag_idsTest = [];
    
    for i = 1:numTotalPoints
        if ismember(bag_ids(i),idxLabs(1,:))
            XTrain = [XTrain; X(i,:)];
            bag_idsTrain = [bag_idsTrain, bag_ids(i)];
        else
            XTest = [XTest; X(i,:)];
            bag_idsTest = [bag_idsTest, bag_ids(i)];
        end
    end
    
    % bagsTrain indicates the bags of the training set    
    bagsTrain = idxLabs(1,:);
    
    % bagsTest indicates the bags of the testing set    
    bagsTest = idxUnls(1,:);
    
    [w, b] = Formulazione2(C,XTrain,bagsTrain,bag_idsTrain,labelsBag,output,summary);
    %[w, b] = Heuristics(C,XTrain,bagsTrain,bag_idsTrain,labelsBag,output,summary);
    print = false;
    correctnessPercentage = correctness(XTrain,idxLabs,bag_idsTrain,labelsBag,w,b,print,output,summary);
    fprintf('TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentage);
    fprintf(output,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentage);
    print = true;
    correctnessPercentage = correctness(XTest,idxUnls,bag_idsTest,labelsBag,w,b,print,output,summary);
    fprintf('TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentage);
    fprintf(output,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentage);
end

if mode == 2
    
    [numFoldLev1,sizeIdxLabs] = size(idxLabs);
    numFoldLev2 = 5;
    gridC = [];
    for i=-7:7
        gridC = [gridC; 2^i];
    end
    
    sumCorrectnessTrain = 0.0;
    sumCorrectnessTest = 0.0;
    sumTime = 0.0;
    
    sumSensitivity = 0.0;
    sumSpecificity = 0.0;
    sumFscore = 0.0;
    sumPrecision = 0.0;
    sumNPV = 0.0;
    sumCappa = 0.0;
    sumMCC = 0.0;
    
    for iFoldLev1 = 1:numFoldLev1
    
        % Xtrain is the matrix of the points of the training set 
        XTrain = [];

        % bag_idsTrain is the part of vector bag_ids corresponding to the training set
        bag_idsTrain = [];
    
        % XTest is the matrix of the points of the testing set 
        XTest = [];

        % bag_idsTest is the part of vector bag_ids corresponding to the testing set
        bag_idsTest = [];
        
%         bagsForTrain = zeros(1,numTotalBags);
%         for i=1:sizeIdxLabs
%             bagsForTrain(idxLabs(iFoldLev1,i)) = 1;
%         end
%         
%         tic
%         for i = 1:numTotalPoints
%             i
%             if bagsForTrain(bag_ids(i)) == 1
%                 XTrain = [XTrain; X(i,:)];
%                 bag_idsTrain = [bag_idsTrain, bag_ids(i)];
%             else
%                 XTest = [XTest; X(i,:)];
%                 bag_idsTest = [bag_idsTest, bag_ids(i)];
%             end
%         end
%         toc
    
        
        for i = 1:numTotalPoints
            fprintf('CREATING FIRST LEVEL FOLD NUMBER %i...WAIT (imax = %i)...i = %i \n',iFoldLev1,numTotalPoints,i);
            if ismember(bag_ids(i),idxLabs(iFoldLev1,:))
                XTrain = [XTrain; X(i,:)];
                bag_idsTrain = [bag_idsTrain, bag_ids(i)];
            else
                XTest = [XTest; X(i,:)];
                bag_idsTest = [bag_idsTest, bag_ids(i)];
            end
        end
        
    
        % bagsTrain indicates the bags of the training set    
        bagsTrain = idxLabs(iFoldLev1,:);

        % bagsTest indicates the bags of the testing set    
        bagsTest = idxUnls(iFoldLev1,:);

        % model selection
%         fprintf('MODEL SELECTION: FOLD %i \n', iFoldLev1);
%         fprintf(output,'MODEL SELECTION: FOLD %i \n', iFoldLev1);
%         fprintf(summary,'MODEL SELECTION: FOLD %i \n', iFoldLev1);
%         C = modelSelection(XTrain,idxLabs(iFoldLev1,:),bag_idsTrain,labelsBag,numFoldLev2,gridC,...
%             iFoldLev1,output,summary);

        C = 1;
        fprintf(summary,'LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        fprintf('LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        fprintf(output,'LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        fprintf(results,'LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        tic();
        [w, b] = Formulazione2(C,XTrain,bagsTrain,bag_idsTrain,labelsBag,output,summary);
        %[w, b] = Heuristics(C,XTrain,bagsTrain,bag_idsTrain,labelsBag,output,summary);     
        timeFold = toc();
        print = false;
        correctnessPercentageTrain = correctness(XTrain,idxLabs(iFoldLev1,:),bag_idsTrain,labelsBag,w,b,...
            print,output,summary);
        fprintf('TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(summary,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(output,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(results,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        
        sumCorrectnessTrain = sumCorrectnessTrain + correctnessPercentageTrain;
        %correctnessPercentageTest = correctness(XTest,idxUnls(iFoldLev1,:),bag_idsTest,labelsBag,w,b,...
        %    print,output,summary);
        [correctnessPercentageTest, TP, TN, FP, FN] = correctness(XTest,idxUnls(iFoldLev1,:),bag_idsTest,labelsBag,w,b,...
            print,output,summary);
        fprintf('TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(summary,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(output,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(results,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        
  
        print = true;
        correctnessPercentageTest = correctness(XTest,idxUnls(iFoldLev1,:),bag_idsTest,labelsBag,w,b,...
            print,output,summary);
        fprintf('TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(summary,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(output,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(results,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(summary,'CPU TIME = %6.2f secs \n', timeFold);
        fprintf(output,'CPU TIME = %6.2f secs\n', timeFold);
        fprintf(results,'CPU TIME = %6.2f secs\n', timeFold);
        
        sumCorrectnessTest = sumCorrectnessTest + correctnessPercentageTest;
        sumTime = sumTime + timeFold;
        sumSensitivity = sumSensitivity + 100*TP/(FN+TP);
        sumSpecificity = sumSpecificity + 100*TN/(FP+TN);
        sumPrecision = sumPrecision + 100*TP/(TP+FP);
        sumNPV = sumNPV + 100*TN/(TN+FN);
        sumFscore = sumFscore + 100*2*TP/(2*TP+FP+FN);
        sumCappa = sumCappa + 2*(TP*TN-FN*FP)/((TP+FP)*(FP+TN)+(TP+FN)*(FN+TN));
        sumMCC = sumMCC + (TP*TN-FP*FN)/sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN));
        
    end
    
    averageCorrectnessTrain = sumCorrectnessTrain/numFoldLev1;
    fprintf('AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
    fprintf(summary,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
    fprintf(output,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
    fprintf(results,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
    
    
    averageCorrectnessTest = sumCorrectnessTest/numFoldLev1;
    fprintf('AVERAGE TESTING CORRECTNESS = %6.2f%% \n', averageCorrectnessTest);
    fprintf(summary,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', averageCorrectnessTest);
    fprintf(output,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', averageCorrectnessTest);
    fprintf(results,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', averageCorrectnessTest);
   
    
    fprintf(results,'AVERAGE TESTING SENSITIVITY = %6.2f%% \n', sumSensitivity/numFoldLev1);
    fprintf(results,'AVERAGE TESTING SPECIFICITY = %6.2f%% \n', sumSpecificity/numFoldLev1);
    fprintf(results,'AVERAGE TESTING PRECISION = %6.2f%% \n', sumPrecision/numFoldLev1);
    fprintf(results,'AVERAGE TESTING NPV = %6.2f%% \n', sumNPV/numFoldLev1);
    fprintf(results,'AVERAGE TESTING FSCORE = %6.2f%% \n', sumFscore/numFoldLev1);
    fprintf(results,'AVERAGE TESTING CAPPA = %6.2f \n', sumCappa/numFoldLev1);
    fprintf(results,'AVERAGE TESTING MCC = %6.2f \n', sumMCC/numFoldLev1);
    
    fprintf('AVERAGE TESTING SENSITIVITY = %6.2f%% \n', sumSensitivity/numFoldLev1);
    fprintf('AVERAGE TESTING SPECIFICITY = %6.2f%% \n', sumSpecificity/numFoldLev1);
    fprintf('AVERAGE TESTING PRECISION = %6.2f%% \n', sumPrecision/numFoldLev1);
    fprintf('AVERAGE TESTING NPV = %6.2f%% \n', sumNPV/numFoldLev1);
    fprintf('AVERAGE TESTING FSCORE = %6.2f%% \n', sumFscore/numFoldLev1);
    fprintf('AVERAGE TESTING CAPPA = %6.2f \n', sumCappa/numFoldLev1);
    fprintf('AVERAGE TESTING MCC = %6.2f \n', sumMCC/numFoldLev1);
    
    averageTime = sumTime/numFoldLev1;
    fprintf('AVERAGE CPU TIME = %6.2f secs \n', averageTime);
    fprintf(summary,'AVERAGE CPU TIME = %6.2f secs \n', averageTime);
    fprintf(output,'AVERAGE CPU TIME = %6.2f secs\n', averageTime);
    fprintf(results,'AVERAGE CPU TIME = %6.2f secs\n', averageTime);
    
end


if mode == 3
    
    [numFoldLev1,sizeIdxLabs] = size(idxLabs);
    
    if dataset == 1
        bestC = [0.015625; 0.0625; 0.03125; 0.03125; 0.03125;
                 0.03125; 0.015625; 0.03125; 0.03125; 0.03125];
    elseif dataset == 2
        bestC = [64; 128; 16; 8; 2; 8; 32; 32; 64; 16];
    elseif dataset == 3
        bestC = [0.125; 0.125; 16; 0.125; 0.0625; 0.5; 0.25; 32; 0.0625; 0.25];
    elseif dataset == 4
        bestC = [4; 4; 4; 4; 4; 4; 4; 4; 4; 4];    
    elseif dataset == 5
        bestC = [4; 4; 4; 4; 4; 4; 4; 4; 4; 4];
    elseif dataset == 6
        bestC = [4; 4; 4; 4; 4; 4; 4; 4; 4; 4];  
    elseif dataset == 7
        bestC = [4; 4; 4; 4; 4; 4; 4; 4; 4; 4];  
    elseif dataset == 8
        bestC = [4; 4; 4; 4; 4; 4; 4; 4; 4; 4]; 
    elseif dataset == 9
        bestC = [4; 4; 4; 4; 4; 4; 4; 4; 4; 4];   
    elseif dataset == 10
        bestC = [4; 4; 4; 4; 4; 4; 4; 4; 4; 4]; 
    elseif dataset == 11
        bestC = [0.0625; 0.125; 0.0625; 0.125; 0.125; 4; 0.0625; 0.125; 0.125; 0.125]; 
    elseif dataset == 12
        bestC = [0.125; 0.015625; 0.125; 0.0625; 0.25; 0.25; 0.0625; 0.5; 0.078125; 0.25];      
    end
    sumCorrectnessTrain = 0.0;
    sumCorrectnessTest = 0.0;
    sumTime = 0.0;
    
    for iFoldLev1 = 1:numFoldLev1
    
        % Xtrain is the matrix of the points of the training set 
        XTrain = [];

        % bag_idsTrain is the part of vector bag_ids corresponding to the training set
        bag_idsTrain = [];
    
        % XTest is the matrix of the points of the testing set 
        XTest = [];

        % bag_idsTest is the part of vector bag_ids corresponding to the testing set
        bag_idsTest = [];
        
%         bagsForTrain = zeros(1,numTotalBags);
%         for i=1:sizeIdxLabs
%             bagsForTrain(idxLabs(iFoldLev1,i)) = 1;
%         end
%         
%         tic
%         for i = 1:numTotalPoints
%             i
%             if bagsForTrain(bag_ids(i)) == 1
%                 XTrain = [XTrain; X(i,:)];
%                 bag_idsTrain = [bag_idsTrain, bag_ids(i)];
%             else
%                 XTest = [XTest; X(i,:)];
%                 bag_idsTest = [bag_idsTest, bag_ids(i)];
%             end
%         end
%         toc
    
        
        for i = 1:numTotalPoints
            fprintf('CREATING FIRST LEVEL FOLD NUMBER %i...WAIT (imax = %i)...i = %i \n',iFoldLev1,numTotalPoints,i);
            if ismember(bag_ids(i),idxLabs(iFoldLev1,:))
                XTrain = [XTrain; X(i,:)];
                bag_idsTrain = [bag_idsTrain, bag_ids(i)];
            else
                XTest = [XTest; X(i,:)];
                bag_idsTest = [bag_idsTest, bag_ids(i)];
            end
        end
        
    
        % bagsTrain indicates the bags of the training set    
        bagsTrain = idxLabs(iFoldLev1,:);

        % bagsTest indicates the bags of the testing set    
        bagsTest = idxUnls(iFoldLev1,:);
        C = bestC(iFoldLev1);
        fprintf(summary,'LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        fprintf('LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        fprintf(output,'LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        fprintf(results,'LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        tic();
        [w, b] = Formulazione2(C,XTrain,bagsTrain,bag_idsTrain,labelsBag,output,summary);
        %[w, b] = Heuristics(C,XTrain,bagsTrain,bag_idsTrain,labelsBag,output,summary);
        timeFold = toc();
        print = false;
        correctnessPercentageTrain = correctness(XTrain,idxLabs(iFoldLev1,:),bag_idsTrain,labelsBag,w,b,...
            print,output,summary);
        fprintf('TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(summary,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(output,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(results,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        
        sumCorrectnessTrain = sumCorrectnessTrain + correctnessPercentageTrain;
        print = true;
        correctnessPercentageTest = correctness(XTest,idxUnls(iFoldLev1,:),bag_idsTest,labelsBag,w,b,...
            print,output,summary);
        fprintf('TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(summary,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(output,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(results,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(summary,'CPU TIME = %6.2f secs \n', timeFold);
        fprintf(output,'CPU TIME = %6.2f secs\n', timeFold);
        fprintf(results,'CPU TIME = %6.2f secs\n', timeFold);
        
        sumCorrectnessTest = sumCorrectnessTest + correctnessPercentageTest;
        sumTime = sumTime + timeFold;
        
    end
    
    averageCorrectnessTrain = sumCorrectnessTrain/numFoldLev1;
    fprintf('AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
    fprintf(summary,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
    fprintf(output,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
    fprintf(results,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
    
    averageTime = sumTime/numFoldLev1;
    fprintf('AVERAGE CPU TIME = %6.2f secs \n', averageTime);
    fprintf(summary,'AVERAGE CPU TIME = %6.2f secs \n', averageTime);
    fprintf(output,'AVERAGE CPU TIME = %6.2f secs\n', averageTime);
    fprintf(results,'AVERAGE CPU TIME = %6.2f secs\n', averageTime);
    
    averageCorrectnessTest = sumCorrectnessTest/numFoldLev1;
    fprintf('AVERAGE TESTING CORRECTNESS = %6.2f%% \n', averageCorrectnessTest);
    fprintf(summary,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', averageCorrectnessTest);
    fprintf(output,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', averageCorrectnessTest);
    fprintf(results,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', averageCorrectnessTest);
    
end

end