function [errFunc, g] = errorFunction(w,gamma,C,X,bags,bag_ids,labelsBag,output,summary)

%gamma = -gamma;

% numPoints is the number of points used to learn the classifier
% dim is the dimension of the space

[numPoints, dim] = size(X);

% numBags is the number of bags used to learn the classifier

[temp, numBags] = size(bags);

% numTotalBags is the number of bags of the entire dataset

[temp, numTotalBags] = size(labelsBag);

errFunc = 0.0;
minValues = inf(1,numTotalBags);
g = 0;

for i=1:numPoints
    if labelsBag(bag_ids(i)) == -1
        temp = X(i,:)*w' + gamma +1;
        if temp > 0.0
            errFunc = errFunc + temp;
            g = g - 1;
        end
    else
        temp = -X(i,:)*w' - gamma +1;
        if temp < minValues(bag_ids(i))
            minValues(bag_ids(i)) = temp;
        end
    end
end

for i=1:numTotalBags
    if minValues(i) ~= inf && minValues(i) > 0
        errFunc = errFunc + minValues(i);
        if minValues(i) >= 0
            g = g + 1;
        end
    end
end

        

