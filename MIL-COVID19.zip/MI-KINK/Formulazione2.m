function [w, gamma] = Formulazione2(C,X,bags,bag_ids,labelsBag,output,results)


tol = 10^-10;

% C is the model selection parameter
% X is the matrix of the points to learn the classifier
% bags is the array containing the bags used to learn the classifier
% bag_ids(i) is the bag to which point i belongs 
% labelsBag is the array of the labels of the all the bags of the dataset

% numPoints is the number of points used to learn the classifier
% dim is the dimension of the space

[numPoints, dim] = size(X);

% numBags is the number of bags used to learn the classifier

[temp, numBags] = size(bags);

% numTotalBags is the number of bags of the entire dataset

[temp, numTotalBags] = size(labelsBag);

setW = 1;

% computing w = b - a, a is the barycenter of all instances of the negative
% bags and b is the barycenter of those of positive bags.

a = zeros(1,dim);
b = zeros(1,dim);

if setW == 0

    numTotPointsInPosBags = 0;
    numTotPointsInNegBags = 0;

    for i=1:numPoints
        if labelsBag(bag_ids(i)) == 1
            b = b + X(i,:);
            numTotPointsInPosBags = numTotPointsInPosBags + 1;
        else
            a = a + X(i,:);
            numTotPointsInNegBags = numTotPointsInNegBags + 1;
        end
    end

    a = a/numTotPointsInNegBags;
    b = b/numTotPointsInPosBags;
    w = b-a;
    
    w = ones(1,dim);
    
elseif setW == 1
    numTotPointsInNegBags = 0;
    numPointsInPosBags = zeros(1,numTotalBags);
    baryCenters = zeros(numTotalBags,dim);
    numPointsInPosBags = zeros(1,numTotalBags);
    for i=1:numPoints
        if labelsBag(bag_ids(i)) == 1
            baryCenters(bag_ids(i),:) = baryCenters(bag_ids(i),:) + X(i,:);
            numPointsInPosBags(bag_ids(i)) = numPointsInPosBags(bag_ids(i)) + 1;
        else
            a = a + X(i,:);
            numTotPointsInNegBags = numTotPointsInNegBags + 1;
        end
    end
    
    numPosBags = 0;
    for i=1:numTotalBags
        if numPointsInPosBags(i) > 0
            numPosBags = numPosBags +1;
            b = b + (baryCenters(i,:)/numPointsInPosBags(i));
        end
    end
    b = b/numPosBags;
    a = a/numTotPointsInNegBags;
    %w = b-a;
    
    %w = b + 10^6 * (b-a);
    w = 10^6*(b-a);
    
else
    
    numPointsInPosBags = zeros(1,numTotalBags);
    numPointsInPosBags = zeros(1,numTotalBags);
    baryCenters = zeros(numTotalBags,dim);
    numPointsInPosBags = zeros(1,numTotalBags);
    numPointsInNegBags = zeros(1,numTotalBags);
    for i=1:numPoints
        if labelsBag(bag_ids(i)) == 1
            baryCenters(bag_ids(i),:) = baryCenters(bag_ids(i),:) + X(i,:);
            numPointsInPosBags(bag_ids(i)) = numPointsInPosBags(bag_ids(i)) + 1;
        else
            baryCenters(bag_ids(i),:) = baryCenters(bag_ids(i),:) + X(i,:);
            numPointsInNegBags(bag_ids(i)) = numPointsInNegBags(bag_ids(i)) + 1;
        end
    end
    
    numPosBags = 0;
    numNegBags = 0;
    for i=1:numTotalBags
        if numPointsInPosBags(i) > 0
            numPosBags = numPosBags +1;
            b = b + (baryCenters(i,:)/numPointsInPosBags(i));
        elseif numPointsInNegBags(i) > 0
            numNegBags = numNegBags +1;
            a = a + (baryCenters(i,:)/numPointsInNegBags(i));
        end
    end
    b = b/numPosBags;
    a = a/numNegBags;
    w = b-a;
    
end


mainIterMax = 1;

for mainIter = 1: mainIterMax 

% alphaBeta(i) indicates the value of alpha for the negative bag i 
% and the value of beta(i) for the positive bag i

for i=1:numTotalBags
    if labelsBag(i) == -1
        alphaBeta(i) = -Inf;
    else
        alphaBeta(i) = Inf;
    end
end

gammaAlpha = -Inf;
gammaBeta = Inf;

for i=1:numPoints
    if labelsBag(bag_ids(i)) == -1
        temp = X(i,:)*w' + 1;
        if temp > alphaBeta(bag_ids(i))
            alphaBeta(bag_ids(i)) = temp;
%             if temp > gammaAlpha
%                 gammaAlpha = temp;
%             end
        end
    else
        temp = -X(i,:)*w' + 1;
        if temp < alphaBeta(bag_ids(i))
            alphaBeta(bag_ids(i)) = temp;
%             if -temp < gammaBeta
%                 gammaBeta = -temp;
%             end
        end
    end
end

for i=1:numTotalBags
    if labelsBag(i) == -1 & alphaBeta(i) ~= -Inf & alphaBeta(i) > gammaAlpha
        gammaAlpha = alphaBeta(i);
    elseif labelsBag(i) == 1 & alphaBeta(i) ~= Inf & -alphaBeta(i) < gammaBeta
        gammaBeta = -alphaBeta(i);
    end
end
            
if gammaAlpha <= gammaBeta
    gamma = -gammaAlpha;
else
    orderAlphaBeta = [];
    for i=1:numTotalBags
        if labelsBag(i) == -1 & alphaBeta(i) ~= -Inf
            orderAlphaBeta = [orderAlphaBeta; [alphaBeta(i) -1]];
        elseif labelsBag(i) == 1 & alphaBeta(i) ~= Inf
            orderAlphaBeta = [orderAlphaBeta; [-alphaBeta(i) 1]];
        end
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%   PL   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% f = ones(numBags+1,1);
% f(numBags+1) = 0;
% A = [-eye(numBags,numBags), ones(numBags,1)];
% b = zeros(numBags,1);
% for i=1:numBags
%    if orderAlphaBeta(i,2)==-1
%        A(i,numBags+1)=-1;
%        b(i)=-orderAlphaBeta(i,1);
%    else
%        b(i)=orderAlphaBeta(i,1);
%    end
% end
% lb = zeros(numBags+1,1);
% lb(numBags+1) = -inf;
% [x, fval] = linprog(f,A,b,[],[],lb,[]);
% gammaLP = -x(numBags+1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    orderAlphaBeta = sortrows(orderAlphaBeta,1);
    index = floor(numBags/2); 
    count = 1;
    while index ~= -1
       kink = orderAlphaBeta(index,1);
       if  kink >= gammaBeta
           tempAlpha=find(orderAlphaBeta(:,2)==-1&orderAlphaBeta(:,1)>kink);
           tempBeta=find(orderAlphaBeta(:,2)==1&orderAlphaBeta(:,1)<kink);
           sizeTempAlpha = size(tempAlpha,1);
           sizeTempBeta = size(tempBeta,1);
           diff = sizeTempBeta - sizeTempAlpha;
           if diff == 0
               gamma = -kink;
               index = -1;
               break;
           elseif diff == 1
               tempAlpha0=find(orderAlphaBeta(:,2)==-1&abs(orderAlphaBeta(:,1)-kink)<=tol);
               if size(tempAlpha0,1)==1
                   gamma = -kink;
                   index = -1;
                   break;
               end
           elseif diff == -1
               tempBeta0=find(orderAlphaBeta(:,2)==1&abs(orderAlphaBeta(:,1)-kink)<=tol);
               if size(tempBeta0,1)==1
                   gamma = -kink;
                   index = -1;
                   break;
               end
           end
           if diff >= 1
               index = index - 1;
           else
               index = index + 1;
           end
       end
       count = count + 1;
       if count == numBags
           gamma = -kink;
           index = -1;
           fprintf(results,'MAXIMUM NUMBER OF KINKS REACHED \n');
           break;
       end
    end
end

%Comparing the objective function value with the LP objective function
%value
%[fval1, g1] = errorFunction(w,gamma,C,X,bags,bag_ids,labelsBag,output,summary);
w = w';

if mainIter < mainIterMax

% improving w;

delta = zeros(dim,1);
minH = Inf(1,numTotalBags);
pointMinH = zeros(numTotalBags,1);
for i=1:numPoints
    if labelsBag(bag_ids(i)) == -1 & X(i,:)*w - gamma + 1 >= 0.0
       delta = delta - X(i,:)';
    elseif labelsBag(bag_ids(i)) == 1  
        temp = -X(i,:)*w + gamma + 1;
        if  temp >= 0.0 & temp < minH(bag_ids(i))
            minH(bag_ids(i)) = temp;
            pointMinH(bag_ids(i)) = i;
        end
    end
end

for i = 1: numTotalBags
    if pointMinH(i) > 0
        delta = delta + X(pointMinH(i),:)';
    end
end 


m = 0.1;
iterMax = 1000;

iter = 0;
alpha = 1;
wTrial = w  + alpha * delta;
wTrial = wTrial';
[fTrial, g] = errorFunction(wTrial,gamma,C,X,bags,bag_ids,labelsBag,output,results);
while fTrial > fval - m * alpha* norm(delta)^2;
    
    iter = iter +1;
    if iter == iterMax
        fprintf(results,'MAX NUMBER OF LINE SEARCHES REACHED \n');
        fprintf('MAX NUMBER OF LINE SEARCHES REACHED \n');
        break;
    end
        
    alpha = alpha*0.8;
    wTrial = w  + alpha * delta;
    wTrial = wTrial';  
    [fTrial, g] = errorFunction(wTrial,gamma,C,X,bags,bag_ids,labelsBag,output,results);
end 
w = wTrial;

end

end

