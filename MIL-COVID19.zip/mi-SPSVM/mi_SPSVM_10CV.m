%<-----------------------INIZIO CODICE mi-SVM----------------------->
for dataset=0:0
    if dataset == 0
        clear;
        results = fopen('res/CovidViralCoo5CV.txt','w');
        load ../Dataset/CovidViralCoo5CV.mat;
        dataset = 0;
    elseif dataset == 1
         clear;
        results = fopen('res/CovidViralCoo10CV.txt','w');
        load ../Dataset/CovidViralCoo10CV.mat;
        dataset = 1;
    end

iterMax = 100;

features = full(features);
labels = full(labels);
bag_ids = full(bag_ids);

crossValidation = true;
numBag = max(bag_ids);

%partition contiene il numero di bag di testing di secondo livello
firstLevelPartition = floor(numBag*0.1);
partition = floor((numBag-firstLevelPartition)*0.2);

[numPoints,dim] = size(features);

%vettore successivamente usato per salvare i 10 valori ottimali di  primo livello di C
bestCFirstLevel = zeros(1,10);

if crossValidation
    for firstLevelIter = 1:10
      
        %secondLevelTestingSet contiene su ogni riga i-esima i bag che user� come
        %test nell'iterazione i-esima di secondo livello
        for i = 1:5
            secondLevelTestingSet(i,1:partition) = idxLabs(firstLevelIter,((partition*(i-1))+1):partition*i);
        end
        
        %in CError inserisco gli errori relativi ai 15 valori diversi di C
        cError = zeros(1,15);
        
        
        for secondLevelIter = 1:5
            numPointsTest = 0;
            numPointsTrain = 0;
            bagTrain=zeros(1,numBag-firstLevelPartition-partition);
            insert=0;
            
            %in bag train metto tutti i bag che non uso come test
            for i = 1:5
                if i~=secondLevelIter
                    bagTrain((insert*partition)+1:(insert+1)*partition) = secondLevelTestingSet(i,1:partition);
                    insert = insert + 1;
                end
            end
            
            %aggiungo come bag di training gli eventuali di scarto
            bagTrain(1,partition*4+1:(numBag-firstLevelPartition)-partition) = idxLabs(firstLevelIter,(partition*5)+1:(numBag-firstLevelPartition));
            
            XTest = double.empty;
            XTrain = double.empty;
            bag_idsTest = double.empty;
            yTest = double.empty;
            bag_idsTrain = double.empty;
            yTrain = double.empty;
            numBagTrain = (numBag-firstLevelPartition)-partition;
            numBagTest= partition;
            
            for i = 1:numPoints
                if ismember(bag_ids(i),secondLevelTestingSet(secondLevelIter,:))
                    XTest = [XTest;features(i,:)];
                    bag_idsTest = [bag_idsTest bag_ids(i)];
                    numPointsTest = numPointsTest+1;
                    yTest = [yTest labels(i)];
                elseif ((ismember(bag_ids(i),bagTrain)))
                    XTrain = [XTrain;features(i,:)];
                    bag_idsTrain = [bag_idsTrain bag_ids(i)];
                    numPointsTrain = numPointsTrain+1;
                    yTrain = [yTrain labels(i)];
                end
            end
            
            %le variabili equivalgono al numero di punti
            numVar = numPointsTrain;
            
            % suppongo che tutti i bag siano negativi
            aboutBag = - ones(numBag,1);
            
            % per ogni punto positivo, inizializzo come positivo il bag
            % cui appartiene
            for i = 1: numPointsTrain
                if(yTrain(i) == 1)
                    aboutBag(bag_idsTrain(i)) = 1;
                end
            end
            
            for i = 1: numPointsTest
                if(yTest(i) == 1)
                    aboutBag(bag_idsTest(i)) = 1;
                end
            end
           
            
            % assegno ad ogni punto di training l'etichetta del suo bag
            for i = 1: numPointsTrain
                yTrain(i) = aboutBag(bag_idsTrain(i));
            end
                      
            yTrain_before = yTrain;
            
            
            for exponent = -7:7
                C = 2^exponent;
                
                
                % booleana usata per gestire le iterazioni del while
                haveToContinue = true;
                
                yTrain = yTrain_before;
                
                fOld = inf;
                numericError = false;
                iter = 1;
                isMisclassified = false;
                
               
                
                % finch� questa booleana � vera eseguo un'altra iterazione
                while haveToContinue == true && numericError == false && iter <= iterMax
                    
                    % salvo le etichette quando inizia l'iterazione
                    labelBeforeComputing = yTrain;
                    
                    XPosNeg = zeros(numPointsTrain,dim);   
                    numPos = 0;
                    numNeg = 0;
                    for i = 1: numPointsTrain
                        if yTrain(i) == 1
                            numPos = numPos +1;
                            XPosNeg(numPos,:) = XTrain(i,:);
                        else
                            numNeg = numNeg +1;
                            XPosNeg(numPointsTrain-(numNeg-1),:) = XTrain(i,:);
                        end
                    end

                    XPos = XPosNeg(1:numPos,:);
                    XNeg = XPosNeg(numPos+1:numPointsTrain,:);     

         
                  
                    numVar = numPos + numNeg;
                    lb = [-inf(numPos,1);zeros(numNeg,1)];
                    ub = [inf(numPos,1);ones(numNeg,1)*C];
                    
                    ePos = ones(numPos,1);
                    eNeg = ones(numNeg,1);
                    e = [ePos;eNeg];

                    H = [XPos*XPos'+ePos*ePos'+(speye(numPos)/C), -XPos*XNeg'-ePos*eNeg';
                         (-XPos*XNeg'-ePos*eNeg')', XNeg*XNeg'+eNeg*eNeg'];
                     
                    opts = optimoptions('quadprog','Display','off'); 
                    [dualVar,fval] = quadprog(H,-e,[],[],[],[],lb,ub,[],opts); 
                    
                    lambda = dualVar(1:numPos);
                    mu = dualVar(numPos+1:numVar);
                    
                    hyperplane = XPos'*lambda - XNeg'* mu;
                   
                    b = eNeg'*mu - ePos'*lambda;
                   
                    
                    %PRIMALE DI PROVA
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%                     fprintf('PRIMAL \n');
%                     tic
%                     numVar = dim+1+numNeg;
%                     A = zeros(numNeg,numVar);
%                     b = - ones(numNeg,1);
%                     for i = 1: numNeg
%                             A(i,1:dim) = XNeg(i,:);
%                             A(i,dim+1) = 1;
%                             A(i,dim+1+i) = -1;
%                     end
%                     ub = [];
%                     lb = zeros(numVar,1);
%                     for i = 1: dim +1
%                         lb(i) = -inf;
%                     end
%                     H = zeros(numVar,numVar);
%                     barX = XPos(1,:)'*XPos(1,:);
%                     barx = XPos(1,:)';
%                     for i=2:numPos
%                         barX = barX + XPos(i,:)'*XPos(i,:);
%                         barx = barx + XPos(i,:)';
%                     end
%                     H = [eye(dim)+C*barX, C*barx, zeros(dim,numNeg);
%                         C* barx', 1+C*numPos, zeros(1,numNeg);
%                         zeros(numNeg,dim), zeros(numNeg,1), zeros(numNeg,numNeg)];
%                     f = [-C*barx;-C*numPos;C*ones(numNeg,1)];
%                     opts = optimoptions('quadprog','Display','off'); 
%                     [x,fvalP] = quadprog(H,f,A,b,[],[],lb,[],[],opts);
%                     fvalP = fvalP + (C * numPos) /2;
%                     v = [x(1:dim)];
%                     b = x(dim+1);
%                     b = -b;
%                     xi = ones(numPos,1)-XPos*v+b*ones(numPos,1);
%                     fvalPrimal = 0.5*norm(v)^2+0.5*b*b+0.5*C*norm(xi)^2 +C*ones(numNeg,1)'*x(dim+2:numVar);
                   
                    
                    fprintf('firstLevelIter = %i; secondLevelIter = %i; exponent = %i; fval = %12.8f; dat = %i \n',...
                        firstLevelIter, secondLevelIter, exponent, -fval, dataset); 
                    
                    %fromPlusToMinus(i) = 1 se l'istanza (i) � candidata a passare
                    %da J+ a J-; = 0 altrimenti
                    fromPlusToMinus = zeros(1,numPointsTrain);
                    
                    % per tutti i punti appartenenti ad un bag positivo
                    for i = 1: numPointsTrain
                        if aboutBag(bag_idsTrain(i)) == 1
                            
                            % creo un vettore pari al punto che sto
                            % esaminando
                            point = XTrain(i,:);
                            
                            % associo a questo punto l'etichetta dipendente
                            % dalla formula
                            %yTrain(i) = sign(dot(hyperplane,point)-b);
                            if (dot(hyperplane,point)-b <= -1 && yTrain(i) == 1)
                                yTrain(i) = -1;
                                fromPlusToMinus(i) = 1;
                            end
                    
                        end
                    end
%                     
%                     % per ogni bag di training
                     for i = 1:numBagTrain
%                         % se questo � positivo
                         if aboutBag(bagTrain(i)) == 1
%                             % lo inizializzo come mal classificato
                             isMisclassified = true;
%                             
%                             % se contiene almeno un'istanza positiva,
%                             % allora lo considero classificato
%                             % correttamente
                             for j = 1: numPointsTrain
                                 if( bag_idsTrain(j) == bagTrain(i) && yTrain(j)==1 )
                                     isMisclassified = false;
                                 end
                             end
%                             
%                             % solo se � mal classificato calcolo il punto,
%                             % appartenente a quel bag, pi� vicino
%                             % all'iperpiano
                             if(isMisclassified)
                                 maxValue = -inf;
                                 index = -1;
                                 fprintf(results,'INFEASIBLE BAG \n');
                                 for j = 1:numPointsTrain
                                     if(bag_idsTrain(j) == bagTrain(i) && fromPlusToMinus(j) == 1)
                                         point = XTrain(j,:);
                                         if(dot(hyperplane,point)-b > maxValue)
                                             maxValue=dot(hyperplane,point)-b;
                                             index = j;
                                         end
                                     end
                                 end
%                                 
%                                 % imposto la sua etichetta (quella del
%                                 % punto pi� vicino) ad 1
%                                 
                                 yTrain(index) = 1;
                             end
                         end
                     end
                    
                    
                    % se e solo se le etichette salvate all'inizio
                    % dell'iterazione e quelle attuali non sono identiche
                    % verr� eseguita un'altra iterazione
                    haveToContinue = ismember(0,labelBeforeComputing==yTrain);
                    
                    iter = iter + 1; 
%                     if (iter > iterMax)
%                         fprintf(results,'MAXIMUM NUMBER OF ITERATION REACHED: ');
%                         fprintf(results, 'fNew = %12.8f; fOld = %12.8f; \n',...
%                             -fval, fOld); 
%                     end
                %haveToContinue = false;        
                end
                
                % inizializzo l'errore a 0
                errorTesting = 0;
                
                % vettore usato per gestire il punto, per ogni bag, in
                % virt� del quale si verifica il massimo valore di (x^T
                % hyperplane -b)
                maxValueBag = -inf(numBag,1);
                
                for j = 1:numPoints
                    
                    % se il valore del prodotto scalare tra l'iperpiano e
                    % il punto � maggiore dell'attuale massimo del relativo
                    % bag allora lo aggiorno
                    if(dot(features(j,:),hyperplane)-b>maxValueBag(bag_ids(j)))
                        maxValueBag(bag_ids(j)) = dot(features(j,:),hyperplane)-b;
                    end
                    
                end
                
                % eseguo il controllo del risultato su tutti i bag
                for i = 1:numBag
                    
                    % se il bag contiene almeno un'istanza positiva ed era
                    % negativo o era positivo ma non contiene nessuna
                    % istanza positiva e se questo fa parte dei bag di
                    % testing per quella iterazione aumento l'errore
                    
                    if((maxValueBag(i) > 0 && aboutBag(i) == -1) || (maxValueBag(i) < 0 && aboutBag(i) == 1))
                        if ismember(i,secondLevelTestingSet(secondLevelIter,:))
                            errorTesting = errorTesting + 1;
                        end
                    end
                end
                %trasformo in percentuale l'errore
                errorTesting = (errorTesting/numBagTest)*100;
                
                %cError contiene in posizione i-esima la somma degli errori
                %ottenuti con C=2^(i-8)
                cError(exponent+8) = cError(exponent+8)+errorTesting;
            end
        end
        %cError/5 avr� in posizione i-esima la media degli errori causati
        %con C=2^(i-8)
        cError = cError/5;
        
        [bestError,bestIndex] = min(cError);
        
        %in bestCFirstLevel salvo l'esponente con cui ho ottenuto l'errore
        %medio pi� basso
        bestCFirstLevel(firstLevelIter) = bestIndex-8;
        fprintf(results,'FOLD NUMBER %i: best C = %i \n', firstLevelIter, ...
            bestCFirstLevel(firstLevelIter));
    end
    
else
%     bestCFirstLevel(1) = -7;
%     bestCFirstLevel(2) = -7;
%     bestCFirstLevel(3) = -7;
%     bestCFirstLevel(4) = -7;
%     bestCFirstLevel(5) = -7;
%     bestCFirstLevel(6) = -7;
%     bestCFirstLevel(7) = -7;
%     bestCFirstLevel(8) = -7;
%     bestCFirstLevel(9) = -7;
%     bestCFirstLevel(10) = -7;    
    for i=1:10
        bestCFirstLevel(i) = -2;
    end    
        
end

%disponendo dei 10 esponenti "ottimi" posso passare alla fase di testing
%finale
finalErrorTraining=zeros(1,10);
finalErrorTesting=zeros(1,10);
executionTime=0;

for i=1:10
    fprintf(results,'i = %i, bestC = %12.8f \n', i, bestCFirstLevel(i));
end

for firstLevelIter = 1:10
    
    %pongo C pari a 2 elevato al valore che ho calcolato precedentemente
    C=2^bestCFirstLevel(firstLevelIter);
    
    numPointsTest = 0;
    numPointsTrain = 0;
    XTest = double.empty;
    XTrain = double.empty;
    bag_idsTest = double.empty;
    yTest = double.empty;
    bag_idsTrain = double.empty;
    yTrain = double.empty;
    numBagTrain = (numBag-firstLevelPartition);
    numBagTest= firstLevelPartition;
    for i = 1:numPoints
        if ismember(bag_ids(i),idxUnls(firstLevelIter,:))
            XTest = [XTest;features(i,:)];
            bag_idsTest = [bag_idsTest bag_ids(i)];
            numPointsTest = numPointsTest+1;
            yTest = [yTest labels(i)];
        else
            XTrain = [XTrain;features(i,:)];
            bag_idsTrain = [bag_idsTrain bag_ids(i)];
            numPointsTrain = numPointsTrain+1;
            yTrain = [yTrain labels(i)];
        end
    end
    
    %le variabili equivalgono al numero di punti
    numVar = numPointsTrain;
    
    % suppongo che tutti i bag siano negativi
    aboutBag = - ones(numBag,1);
    
    % per ogni punto positivo, inizializzo come positivo il bag cui
    % appartiene
    for i = 1: numPointsTrain
        if(yTrain(i) == 1)
            aboutBag(bag_idsTrain(i)) = 1;
        end
    end
    
    for i = 1: numPointsTest
        if(yTest(i) == 1)
            aboutBag(bag_idsTest(i)) = 1;
        end
    end
    
    % assegno ad ogni punto di training l'etichetta del suo bag
    for i = 1: numPointsTrain
        yTrain(i) = aboutBag(bag_idsTrain(i));
    end
    
    % booleana usata per gestire le iterazioni del while
    haveToContinue = true;
    
    tic();
    % finch� questa booleana � vera eseguo un'altra iterazione
    
    fOld = inf;
    numericError = false;
    iter = 1;
    isMisclassified = false;
    
    while haveToContinue == true && numericError == false && iter <= iterMax
     
        % salvo le etichette quando inizia l'iterazione
        labelBeforeComputing = yTrain;
        
        numPos = 0;
        numNeg = 0;
        XPosNeg = zeros(numPointsTrain,dim);
        for i = 1: numPointsTrain
            if yTrain(i) == 1
                numPos = numPos +1;
                XPosNeg(numPos,:) = XTrain(i,:);
            else
                numNeg = numNeg +1;
                XPosNeg(numPointsTrain-(numNeg-1),:) = XTrain(i,:);
            end
        end

        XPos = XPosNeg(1:numPos,:);
        XNeg = XPosNeg(numPos+1:numPointsTrain,:);              

        numVar = numPos + numNeg;
        lb = [-inf(numPos,1);zeros(numNeg,1)];
        ub = [inf(numPos,1);ones(numNeg,1)*C];

        ePos = ones(numPos,1);
        eNeg = ones(numNeg,1);
        e = [ePos;eNeg];

        H = [XPos*XPos'+ePos*ePos'+(speye(numPos)/C), -XPos*XNeg'-ePos*eNeg';
             (-XPos*XNeg'-ePos*eNeg')', XNeg*XNeg'+eNeg*eNeg'];

        opts = optimoptions('quadprog','Display','off'); 
        [dualVar,fval] = quadprog(H,-e,[],[],[],[],lb,ub,[],opts); 

        lambda = dualVar(1:numPos);
        mu = dualVar(numPos+1:numVar);

        hyperplane = XPos'*lambda - XNeg'* mu;

        b = eNeg'*mu - ePos'*lambda;
                   
      
        fprintf('LEARNING: firstLevelIter = %i; fval = %12.8f; dat = %i \n',...
                        firstLevelIter, -fval, dataset); 
        
        %fromPlusToMinus(i) = 1 se l'istanza (i) � candidata a passare
        %da J+ a J-; = 0 altrimenti
        fromPlusToMinus = zeros(1,numPointsTrain);
        % per tutti i punti appartenenti ad un bag positivo
        for i = 1: numPointsTrain
            if aboutBag(bag_idsTrain(i)) == 1
                
                % creo un vettore pari al punto che sto esaminando
                point = XTrain(i,:);
                
                % associo a questo punto l'etichetta dipendente dalla
                % formula
                %yTrain(i) = sign(dot(hyperplane,point)-b);
                if (dot(hyperplane,point)-b <= -1 && yTrain(i) == 1)
                    yTrain(i) = -1;
                    fromPlusToMinus(i) = 1;
                end
            end
        end
        
        % per ogni bag di training
         for i = 1:numBagTrain
%             % se questo � positivo
             if aboutBag(idxLabs(firstLevelIter,i)) == 1
%                 % lo inizializzo come mal classificato
                 isMisclassified = true;
%                 
%                 % se contiene almeno un'istanza positiva, allora lo
%                 % considero classificato correttamente

                 
                 for j = 1: numPointsTrain
                     if( bag_idsTrain(j) == idxLabs(firstLevelIter,i) && yTrain(j)==1 )
                         isMisclassified = false;
                     end
                 end
%                 
%                 % solo se � mal classificato calcolo il punto, appartenente
%                 % a quel bag, pi� vicino all'iperpiano
                 if(isMisclassified)
                     maxValue = -inf;
                     index = -1;
                     fprintf(results,'INFEASIBLE BAG \n');
                     for j = 1:numPointsTrain
                         if(bag_idsTrain(j) == idxLabs(firstLevelIter,i) && fromPlusToMinus(j)==1)
                             point = XTrain(j,:);
                             if(dot(hyperplane,point)-b > maxValue)
                                 maxValue=dot(hyperplane,point)-b;
                                 index = j;
                             end
                         end
                     end
%                     % imposto la sua etichetta (quella del punto pi�
%                     % vicino) ad 1
                     yTrain(index) = 1;
                 end
             end
         end
        % se e solo se le etichette salvate all'inizio dell'iterazione e
        % quelle attuali non sono identiche verr� eseguita un'altra
        % iterazione
       
        haveToContinue = ismember(0,labelBeforeComputing==yTrain);
        
        iter = iter + 1;
%         if (iter > iterMax)
%             fprintf(results,'LEARNING - MAXIMUM NUMBER OF ITERATION REACHED: ');
%             fprintf(results, 'fNew = %12.8f; fOld = %12.8f; \n',...
%                 -fval, fOld); 
%         end
        % haveToContinue = false;       
    end
    
    executionTime=executionTime+toc();
    
    % inizializzo gli errori a 0
    errorTraining = 0;
    errorTesting = 0;
    
    % vettore usato per gestire il punto, per ogni bag, in virt� del quale
    % si verifica il massimo valore di (x^T hyperplane -b)
    maxValueBag = -inf(numBag,1);
    for j = 1:numPoints
        % se il valore del prodotto scalare tra l'iperpiano e il punto �
        % maggiore dell'attuale massimo del relativo bag allora lo aggiorno
        if(dot(features(j,:),hyperplane)-b>maxValueBag(bag_ids(j)))
            maxValueBag(bag_ids(j)) = dot(features(j,:),hyperplane)-b;
        end
    end
    
    numBagPos = 0;
    numBagNeg = 0;
    numBagClassAsPos = 0;
    numBagPosCorrClass = 0;
    numBagNegCorrClass = 0;
    
     TP = 0;
    TN = 0;
    FP = 0;
    FN = 0;
    
    
    % eseguo il controllo del risultato su tutti i bag
    for i = 1:numBag
        % se il bag contiene almeno un'istanza positiva ed era negativo o
        % era positivo ma non contiene nessuna istanza positiva aumento
        % il relativo errore
        
        %calcolo variabili per precision, f-score ecc
        if ismember(i,idxUnls(firstLevelIter,:))
            if aboutBag(i) == 1
                numBagPos = numBagPos + 1;
            else
                numBagNeg = numBagNeg + 1;
            end
            if maxValueBag(i) > 0
                numBagClassAsPos = numBagClassAsPos + 1;
                if aboutBag(i) == 1
                    TP = TP + 1;
                    numBagPosCorrClass = numBagPosCorrClass + 1;
                else
                    FP = FP +1;
                end
            elseif maxValueBag(i)<0 
                if (aboutBag(i) == -1)
                    numBagNegCorrClass = numBagNegCorrClass + 1;
                    TN = TN +1;
                else
                    FN = FN +1;
                end
            end   
        end
        
        if((maxValueBag(i) > 0 && aboutBag(i) == -1) || (maxValueBag(i)<0 && aboutBag(i) == 1))
            if ismember(i,idxUnls(firstLevelIter,:))
                errorTesting = errorTesting + 1;
            else
                errorTraining = errorTraining + 1;
            end
        end
    end
    
      
    %trasformo in percentuale i due errori
    finalErrorTraining(1,firstLevelIter)=(errorTraining/numBagTrain)*100;
    finalErrorTesting(1,firstLevelIter)=(errorTesting/numBagTest)*100;
   
%     finalSensitivityTesting(1,firstLevelIter)=(numBagPosCorrClass/numBagPos)*100;
%     finalSpecificityTesting(1,firstLevelIter)=(numBagNegCorrClass/numBagNeg)*100;  
%     precision = numBagPosCorrClass/numBagClassAsPos;
%     sensitivity = finalSensitivityTesting(1,firstLevelIter)/100;
%     finalFscoreTesting(1,firstLevelIter)=(((2*sensitivity*precision)/(sensitivity+precision))*100);
%     finalSensitivityTesting(1,firstLevelIter)=(numBagPosCorrClass/numBagPos)*100;

    finalSensitivityTesting(1,firstLevelIter)=100*TP/(FN+TP);
    finalSpecificityTesting(1,firstLevelIter)=100*TN/(FP+TN);
    finalPrecisionTesting(1,firstLevelIter)=100*TP/(TP+FP);
    finalNPVTesting(1,firstLevelIter)=100*TN/(TN+FN);
    finalFscoreTesting(1,firstLevelIter)=100*2*TP/(2*TP+FP+FN);
    finalCappaTesting(1,firstLevelIter)=2*(TP*TN-FN*FP)/((TP+FP)*(FP+TN)+(TP+FN)*(FN+TN));
    finalMCCTesting(1,firstLevelIter)=(TP*TN-FP*FN)/sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN));
    
    
    fprintf(results,'FOLD N. %i: TRAINING CORRECTNESS = %6.2f%% \n', firstLevelIter, ...
        100-finalErrorTraining(1,firstLevelIter));
    fprintf(results,'FOLD N. %i: TESTING CORRECTNESS = %6.2f%% \n', firstLevelIter, ...
        100-finalErrorTesting(1,firstLevelIter));
    
    fprintf(results,'FOLD N. %i: TESTING Sensitivity = %6.2f%% \n', firstLevelIter, ...
    finalSensitivityTesting(1,firstLevelIter));
    
    fprintf(results,'FOLD N. %i: TESTING Specificity = %6.2f%% \n', firstLevelIter, ...
    finalSpecificityTesting(1,firstLevelIter));

    fprintf(results,'FOLD N. %i: TESTING F-score = %6.2f%% \n', firstLevelIter, ...
    finalFscoreTesting(1,firstLevelIter));
    
end

testingCorrectness = 100-(mean(finalErrorTesting));
trainingCorrectness = 100-(mean(finalErrorTraining));

testingSensitivity = mean(finalSensitivityTesting);
testingSpecificity = mean(finalSpecificityTesting);
testingPrecision = mean(finalPrecisionTesting);
testingNPV = mean(finalNPVTesting);
testingFscore = mean(finalFscoreTesting);
testingCappa= mean(finalCappaTesting);
testingMCC = mean(finalMCCTesting);

%ELIMINATO 10 AGGIUNTO 5
executionTime=executionTime/5;

fprintf('AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', trainingCorrectness);
fprintf('AVERAGE TESTING CORRECTNESS = %6.2f%% \n', testingCorrectness);
fprintf('AVERAGE TESTING Sensitivity = %6.2f%% \n', testingSensitivity);
fprintf('AVERAGE TESTING Specificity = %6.2f%% \n', testingSpecificity);
fprintf('AVERAGE TESTING Precision = %6.2f%% \n', testingPrecision);
fprintf('AVERAGE TESTING NPV = %6.2f%% \n', testingNPV);
fprintf('AVERAGE TESTING Fscore = %6.2f%% \n', testingFscore);
fprintf('AVERAGE TESTING Cappa = %6.2f \n', testingCappa);
fprintf('AVERAGE TESTING MCC = %6.2f \n', testingMCC);

fprintf('AVERAGE CPU TIME = %6.2f secs \n', executionTime);

fprintf(results,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', trainingCorrectness);
fprintf(results,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', testingCorrectness);
fprintf(results,'AVERAGE TESTING Sensitivity = %6.2f%% \n', testingSensitivity);
fprintf(results,'AVERAGE TESTING Specificity = %6.2f%% \n', testingSpecificity);
fprintf(results,'AVERAGE TESTING Precision = %6.2f%% \n', testingPrecision);
fprintf(results,'AVERAGE TESTING NPV = %6.2f%% \n', testingNPV);
fprintf(results,'AVERAGE TESTING Fscore = %6.2f%% \n', testingFscore);
fprintf(results,'AVERAGE TESTING Cappa = %6.2f \n', testingCappa);
fprintf(results,'AVERAGE TESTING MCC = %6.2f \n', testingMCC);
fprintf(results,'AVERAGE CPU TIME = %6.2f secs \n', executionTime);

end


