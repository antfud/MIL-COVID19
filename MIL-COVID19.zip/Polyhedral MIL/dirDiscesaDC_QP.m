function [WStar,gammaStar,fWstar]=dirDiscesaDC_QP(A,B,m,k,h,W,gamma,n,C)
%*************************
% Problema di PL
%*************************

    JBmax = epsX_JXmax(B,W,gamma);

    f=zeros(m+k+h*n+h,1); 
    for j=1:h
        jmax=find(JBmax(:,j));
        for l=1:size(jmax,1)
            f(m+k+(j-1)*n+1:m+k+(j-1)*n+n)=f(m+k+(j-1)*n+1:m+k+(j-1)*n+n)-...
                (1/k)*B(jmax(l),:)';
  %                (C)*B(jmax(l),:)';
          f(m+k+h*n+j)=f(m+k+h*n+j)+(1/k);
 %           f(m+k+h*n+j)=f(m+k+h*n+j)+(C);
        end
    end
    %*********************************************************************
    Av=zeros(m*h+k*h,m+k+h*n+h);
    bv=[-ones(m*h,1);
         ones(k*h,1)];
     
    for i=1:m
        Av((i-1)*h+1:(i-1)*h+h,i)=-ones(h,1);
        for j=1:h
            Av((i-1)*h+j,m+k+(j-1)*n+1:m+k+(j-1)*n+n)=A(i,:);
        end
        Av((i-1)*h+1:(i-1)*h+h,m+k+n*h+1:m+k+n*h+h)=-eye(h);
        f(i)=1/m; 
%        f(i)=C; 
    end

    for i=1:k
        Av(m*h+(i-1)*h+1:m*h+(i-1)*h+h,m+i)=-ones(h,1);
        for j=1:h
            Av(m*h+(i-1)*h+j,m+k+(j-1)*n+1:m+k+(j-1)*n+n)=B(i,:);
        end
        Av(m*h+(i-1)*h+1:m*h+(i-1)*h+h,m+k+n*h+1:m+k+n*h+h)=-eye(h);
        f(m+i)=1/k; 
%        f(m+i)=C; 
    end     
    %*********************************************************************
    lb=-Inf*ones(m+k+h*n+h,1); 
    lb(1:m+k)=0; 
    ub=Inf*ones(m+k+h*n+h,1);
    %*********************************************************************
    
    Hv=zeros(m+k+h*n+h,m+k+h*n+h);
    for i=m+k+1:m+k+h*n
        Hv(i,i)=C;
    end
    
    [x, fval] = cplexqp (Hv, f, Av, bv, [], [], lb, ub);
    
    %*********************************************************************
%    [x,fval]=linprog(f,Av,bv,[],[],lb,ub);
    
%    [x, fval] = cplexlp (f, Av, bv, [], [], lb, ub);
    %*********************************************************************

    fWstar=fval+1;
    WStar=zeros(n,h);
    gammaStar=zeros(h,1);
    for j=1:h
        WStar(:,j)=x(m+k+(j-1)*n+1:m+k+(j-1)*n+n);
        gammaStar(j)=x(m+k+h*n+j);
    end
end

