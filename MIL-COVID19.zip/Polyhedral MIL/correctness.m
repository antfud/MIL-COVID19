function [correctnessPercentage, TP, TN, FP, FN, errorPos,...
    errorNeg] = correctness(X,bags,bag_ids,labelsBag,W,gamma,print,output,summary)


[numPoints, dim] = size(X);
 
[temp, numTotalBags] = size(labelsBag);
[temp, numBags] = size(bags);

if labelsBag(bags(1)) == 1
    numPosBag = 1;
else
    numPosBag = 0;
end
for i=2:numBags
    if labelsBag(bags(i)) == 1
        numPosBag = numPosBag + 1;
    end
end
numNegBag = numBags - numPosBag;


bagLab = -ones(1,max(bags));
classifiedPos = 0;

for j = 1:numPoints
    negative = false;
    for i = 1:size(gamma,1)
        if(dot(W(:,i),X(j,:)) - gamma(i) > 0)
            negative = true;
        end
    end
    
    if(negative == false)
        bagLab(bag_ids(j)) = 1;
    end
end
   
error = 0;
errorPos = 0;
errorNeg = 0;

TP = 0;
TN = 0;
FP = 0;
FN = 0;


for i = 1:numBags
    if bagLab(bags(i)) == 1
        classifiedPos = classifiedPos +1;
    end
    if bagLab(bags(i)) == -1 
        if labelsBag(bags(i)) == 1
            FN = FN +1;
            error = error + 1;
            errorPos = errorPos + 1;
            if print == true
                fprintf(output,'CLASSIFICATON ERROR: POSITIVE BAG N. %i CLASSIFIED AS NEGATIVE \n',bags(i));  
            end
        else
            TN = TN + 1;
        end            
    end
    if bagLab(bags(i)) == 1 
        if labelsBag(bags(i)) == -1
            FP = FP +1;
            error = error + 1;
            errorNeg = errorNeg + 1;
            if print == true
                fprintf(output,'CLASSIFICATON ERROR: NEGATIVE BAG N. %i CLASSIFIED AS POSITIVE \n',bags(i));  
            end
        else
            TP = TP +1;
        end
    end
end

fprintf(output,'%i BAGS MISCLASSIFIED over %i: %i POSITIVE and %i NEGATIVE \n', ...
    error,numBags,errorPos,errorNeg);
fprintf(summary,'%i BAGS MISCLASSIFIED over %i: %i POSITIVE and %i NEGATIVE \n', ...
    error,numBags,errorPos,errorNeg);

correctnessPercentage = 100 - (error/numBags) * 100;


