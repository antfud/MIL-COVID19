
function [W,gamma]=PolyhedralSepDC_QP(A, B, h, sigma,C)
    % A=[a_1^T; a_2^T; ... ; a_m^T] i punti sono per riga
    % B=[b_1^T; b_2^T; ... ; b_k^T] i punti sono per riga 
    % V=[v_1, v_2, ... , v_h] normali agli iperpiani per colonna
    % gamma=[gamma_1;gamma_2;...;gamma_h] un vettore colonna

    
    % Iteration DCA
    nIterMax=3; 

    %*************************************************************
    [m,n]=size(A);
    [k,n]=size(B);
 
    % Inizializzazione iperpiani (V,gamma)
    for j=1:h
        W(:,j)=j*(-1)^j*ones(n,1);
        gamma=j*ones(h,1);
    end
  
   % Valore della funzione di errore
   fW=valFunctionError(A,B,W,gamma)+C*(1/2)*W'*W;
   %fprintf(1,'\nfW =  %3.6f \n',fW);
   nIter=1;
   STOP=false;
   while(nIter<=nIterMax)&&(STOP==false)
       [Wnew,gammaNew,fWnew]=dirDiscesaDC_QP(A,B,m,k,h,W,gamma,n,C);
       fWtemp=valFunctionError(A,B,Wnew,gammaNew)+C*(1/2)*Wnew'*Wnew;

       if (abs(fWnew-fW) <= sigma)
           STOP=true;
       else
           W=Wnew;
           gamma=gammaNew;
           fW=fWtemp;
           nIter=nIter+1;
       end
   end

end


