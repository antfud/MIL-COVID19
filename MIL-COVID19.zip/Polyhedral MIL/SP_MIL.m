function [W, gamma,numIter] = SP_MIL(C,X,bags,bag_ids,labelsBag,output,summary)

    % numPoints is the number of points used to learn the classifier
    % dim is the dimension of the space

    [numPoints, dim] = size(X);

    % numBags is the number of bags used to learn the classifier

    [temp, numBags] = size(bags);

    % numTotalBags is the number of bags of the entire dataset

    [temp, numTotalBags] = size(labelsBag);
    
    for i=1:numPoints
        if labelsBag(bag_ids(i)) == 1
            y(i) = 1;
        else
            y(i) = -1;
        end
    end
    
    exit = false; %used to break the while in some cases
       
    haveToContinue = true;
    numIter = 0;

    % in the while max number of iter of BCD
    while(haveToContinue & numIter <= 10)
        numIter = numIter + 1;

        oldy = y; %save the old labels

        [A,B, index_A, index_B] = computeAandB(y, numPoints, X);
        
        [W,gamma] = PolyhedralSepDC_QP(A,B,2,10^-3,C); 
       
        %update the labels for the points belonging to positive bags
        [y, closest,minDist] = update_y(A,index_A,B,index_B,bag_ids,bags,y,labelsBag,W,gamma);

        %recover feasibility for positive bags currently misclassified
        y = recover_feasibility(y,closest,minDist, numBags,bags,labelsBag,bag_ids);

        %check whether to continue 
        haveToContinue = ismember(0,y==oldy);
    
    end

    
end

function [A,B, index_A, index_B] = computeAandB(y, numPoints, X)
    A = [];
    B = [];
    index_A = [];
    index_B = [];
    for i=1:numPoints
        if y(i) == 1
            A = [A;X(i,:)];
            index_A=[index_A;i];
        else 
            B = [B;X(i,:)];
            index_B=[index_B;i];
        end
    end
end

function [y, closest,minDist] = update_y(A,index_A,B,index_B,bag_ids,bags,y,labelsBag,W,gamma)
    minDist = Inf(1,max(bags));
    closest = -ones(1,max(bags));
    for i=1:size(A,1)
        sum_i = 0;
        for j=1:size(gamma,1)
            hyperVal = dot(W(:,j),A(i,:)) - gamma(j);
            if hyperVal > 0               
                y(index_A(i)) = -1;
                sum_i = sum_i + hyperVal;
            end
        end
        
        if sum_i<minDist(bag_ids(index_A(i)))
            minDist(bag_ids(index_A(i))) = sum_i;
            closest(bag_ids(index_A(i))) = index_A(i);
        end
        
    end
    for i=1:size(B,1)
        if labelsBag(bag_ids(index_B(i))) == -1
            continue;
        end
        outside = false;
        sum_i = 0;

        for j=1:size(gamma,1)
            hyperVal = dot(W(:,j),B(i,:)) - gamma(j);
            if hyperVal > 0  
                outside = true;
                sum_i = sum_i + hyperVal;
            end
        end    
        if ~outside
            y(index_B(i)) = 1;       
        else
            if sum_i<minDist(bag_ids(index_B(i)))
                minDist(bag_ids(index_B(i))) = sum_i;
                closest(bag_ids(index_B(i))) = index_B(i);
            end
        end
    end
end

function y = recover_feasibility(y, closest, minDist, numBags,bags,labelsBag,bag_ids)
    for i = 1:numBags
        if labelsBag(bags(i)) == 1 & minDist(bags(i))>0 & minDist(bags(i)) < inf
            y(closest(bags(i))) = 1;
        end
    end
end
