for dataset=0:0
    
    %% 43grw1q
    
    if dataset == 0
        clear;
        results=fopen('res/results-CovidViralCoo10CV.txt','w');
        output = fopen('res/output-CovidViralCoo10CV.txt','w');
        summary = fopen('res/summary-CovidViralCoo10CV.txt','w');
        load ../Dataset/CovidViralCoo10CV.mat;
        dataset = 0;
    elseif dataset == 1
        clear;
        results=fopen('res/results-CovidViralCoo5CV.txt','w');
        output = fopen('res/output-CovidViralCoo5CV.txt','w');
        summary = fopen('res/summary-CovidViralCoo5CV.txt','w');
        load ../Dataset/CovidViralCoo5CV.mat;
        dataset = 1;
    end
    
    mode = 2;


% fprintf(output,'melanoma32325 \n\n');
% fprintf(summary,'melanoma32325 \n\n');
% fprintf(results,'melanoma32325 \n\n');

% X is the matrix containing in its rows the features%
X = full(features);

% labels(i) is the true label of point i
labels = full(labels);

% bag_ids(i) is the bag to which point i belongs
bag_ids = full(bag_ids);

% numTotalBags is the total number of bags
numTotalBags = max(bag_ids);

% numTotalPoints is the total number of points
% dim is the dimension of the space
[numTotalPoints, dim] = size(X);

% labelsBag(i) is the label of bag i
for i= 1: numTotalBags
    labelsBag(i) = -1;
end
for i=1:numTotalPoints
  if labels(i) == 1
      labelsBag(bag_ids(i)) = 1;
  end
end



[numFoldLev1,sizeIdxLabs] = size(idxLabs);
numFoldLev2 = 5;
gridC = [];
for i=-7:2:-1
    gridC = [gridC; 2^i];
end

sumCorrectnessTrain = zeros(size(gridC,1),1);
sumCorrectnessTest = zeros(size(gridC,1),1);
sumSensitivityTest = zeros(size(gridC,1),1);
sumSpecificityTest = zeros(size(gridC,1),1);
sumFScoreTest = zeros(size(gridC,1),1);
sumPrecisionTest = zeros(size(gridC,1),1);
sumNPVTest = zeros(size(gridC,1),1);
sumCappaTest = zeros(size(gridC,1),1);
sumMCCTest = zeros(size(gridC,1),1);

sumTime = zeros(size(gridC,1),1);

for iFoldLev1 = 1:numFoldLev1
    
    % Xtrain is the matrix of the points of the training set 
    XTrain = [];

    % bag_idsTrain is the part of vector bag_ids corresponding to the training set
    bag_idsTrain = [];

    % XTest is the matrix of the points of the testing set 
    XTest = [];

    % bag_idsTest is the part of vector bag_ids corresponding to the testing set
    bag_idsTest = [];

%         bagsForTrain = zeros(1,numTotalBags);
%         for i=1:sizeIdxLabs
%             bagsForTrain(idxLabs(iFoldLev1,i)) = 1;
%         end
%         
%         tic
%         for i = 1:numTotalPoints
%             i
%             if bagsForTrain(bag_ids(i)) == 1
%                 XTrain = [XTrain; X(i,:)];
%                 bag_idsTrain = [bag_idsTrain, bag_ids(i)];
%             else
%                 XTest = [XTest; X(i,:)];
%                 bag_idsTest = [bag_idsTest, bag_ids(i)];
%             end
%         end
%         toc


    for i = 1:numTotalPoints
        %fprintf('CREATING FIRST LEVEL FOLD NUMBER %i...WAIT (imax = %i)...i = %i \n',iFoldLev1,numTotalPoints,i);
        if ismember(bag_ids(i),idxLabs(iFoldLev1,:))
            XTrain = [XTrain; X(i,:)];
            bag_idsTrain = [bag_idsTrain, bag_ids(i)];
        else
            XTest = [XTest; X(i,:)];
            bag_idsTest = [bag_idsTest, bag_ids(i)];
        end
    end


    % bagsTrain indicates the bags of the training set    
    bagsTrain = idxLabs(iFoldLev1,:);

    % bagsTest indicates the bags of the testing set    
    bagsTest = idxUnls(iFoldLev1,:);

    for iterC = 1:size(gridC,1)
        C = gridC(iterC);
        
        fprintf(summary,'LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        fprintf('LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        fprintf(output,'LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        fprintf(results,'LEARNING PHASE (FOLD n. %i), with C = %12.8f \n', iFoldLev1, C);
        tic();
        [W, gamma] = SP_MIL(C,XTrain,bagsTrain,bag_idsTrain,labelsBag,output,summary);
        timeFold = toc();
        print = false;
        correctnessPercentageTrain = ... 
            correctness(XTrain,idxLabs(iFoldLev1,:),bag_idsTrain,labelsBag,W,gamma,...
            print,output,summary);
        fprintf('TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(summary,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(output,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);
        fprintf(results,'TRAINING CORRECTNESS = %6.2f%% \n', correctnessPercentageTrain);


        print = true;
        [correctnessPercentageTest, TP, TN, FP, FN, errorPos,...
        errorNeg] = ...  
            correctness(XTest,idxUnls(iFoldLev1,:),bag_idsTest,labelsBag,W,gamma,...
            print,output,summary);
        fprintf('TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(summary,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(output,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(results,'TESTING CORRECTNESS = %6.2f%% \n', correctnessPercentageTest);
        fprintf(summary,'CPU TIME = %6.2f secs \n', timeFold);
        fprintf(output,'CPU TIME = %6.2f secs\n', timeFold);
        fprintf(results,'CPU TIME = %6.2f secs\n', timeFold);
       
      
        sumCorrectnessTrain(iterC) = sumCorrectnessTrain(iterC) + correctnessPercentageTrain;     
        sumCorrectnessTest(iterC) = sumCorrectnessTest(iterC) + correctnessPercentageTest;
        sumSensitivityTest(iterC) = sumSensitivityTest(iterC) + 100*TP/(FN+TP);
        sumSpecificityTest(iterC) = sumSpecificityTest(iterC) + 100*TN/(FP+TN);
        sumPrecisionTest(iterC) = sumPrecisionTest(iterC) + 100*TP/(TP+FP);
        sumNPVTest(iterC) = sumNPVTest(iterC) + 100*TN/(TN+FN);
        sumFScoreTest(iterC) = sumFScoreTest(iterC) + 100*2*TP/(2*TP+FP+FN);
        sumCappaTest(iterC) = sumCappaTest(iterC) + 2*(TP*TN-FN*FP)/((TP+FP)*(FP+TN)+(TP+FN)*(FN+TN));
        sumMCCTest(iterC) = sumMCCTest(iterC) + (TP*TN-FP*FN)/sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN));
            
        
        sumTime(iterC) = sumTime(iterC) + timeFold;

    end

end

averageCorrectnessTest = sumCorrectnessTest/numFoldLev1;
[bestCorrectness, bestCIndex] = max(averageCorrectnessTest);

averageCorrectnessTrain = sumCorrectnessTrain(bestCIndex)/numFoldLev1;
fprintf('AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
fprintf(summary,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
fprintf(output,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);
fprintf(results,'AVERAGE TRAINING CORRECTNESS = %6.2f%% \n', averageCorrectnessTrain);

fprintf('AVERAGE TESTING CORRECTNESS = %6.2f%% \n', bestCorrectness);
fprintf(summary,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', bestCorrectness);
fprintf(output,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', bestCorrectness);
fprintf(results,'AVERAGE TESTING CORRECTNESS = %6.2f%% \n', bestCorrectness);

averageSensitivityTest = sumSensitivityTest(bestCIndex)/numFoldLev1;

fprintf('AVERAGE TESTING SENSITIVITY = %6.2f%% \n', averageSensitivityTest);
fprintf(summary,'AVERAGE TESTING SENSITIVITY = %6.2f%% \n', averageSensitivityTest);
fprintf(output,'AVERAGE TESTING SENSITIVITY = %6.2f%% \n', averageSensitivityTest);
fprintf(results,'AVERAGE TESTING SENSITIVITY = %6.2f%% \n', averageSensitivityTest);

averageSpecificityTest = sumSpecificityTest(bestCIndex)/numFoldLev1;

fprintf('AVERAGE TESTING SPECIFICITY = %6.2f%% \n', averageSpecificityTest);
fprintf(summary,'AVERAGE TESTING SPECIFICITY = %6.2f%% \n', averageSpecificityTest);
fprintf(output,'AVERAGE TESTING SPECIFICITY = %6.2f%% \n', averageSpecificityTest);
fprintf(results,'AVERAGE TESTING SPECIFICITY = %6.2f%% \n', averageSpecificityTest);

averagePrecisionTest = sumPrecisionTest(bestCIndex)/numFoldLev1;

fprintf('AVERAGE TESTING PRECISION = %6.2f%% \n', averagePrecisionTest);
fprintf(summary,'AVERAGE TESTING PRECISION = %6.2f%% \n', averagePrecisionTest);
fprintf(output,'AVERAGE TESTING PRECISION = %6.2f%% \n', averagePrecisionTest);
fprintf(results,'AVERAGE TESTING PRECISION = %6.2f%% \n', averagePrecisionTest);

averageNPVTest = sumNPVTest(bestCIndex)/numFoldLev1;

fprintf('AVERAGE TESTING NPV = %6.2f%% \n', averageNPVTest);
fprintf(summary,'AVERAGE TESTING NPV = %6.2f%% \n', averageNPVTest);
fprintf(output,'AVERAGE TESTING NPV = %6.2f%% \n', averageNPVTest);
fprintf(results,'AVERAGE TESTING NPV = %6.2f%% \n', averageNPVTest);

averageFScoreTest = sumFScoreTest(bestCIndex)/numFoldLev1;

fprintf('AVERAGE TESTING F-SCORE = %6.2f%% \n', averageFScoreTest);
fprintf(summary,'AVERAGE TESTING F-SCORE = %6.2f%% \n', averageFScoreTest);
fprintf(output,'AVERAGE TESTING F-SCORE = %6.2f%% \n', averageFScoreTest);
fprintf(results,'AVERAGE TESTING F-SCORE = %6.2f%% \n', averageFScoreTest);

averageCappaTest = sumCappaTest(bestCIndex)/numFoldLev1;

fprintf('AVERAGE TESTING CAPPA = %6.2f \n', averageCappaTest);
fprintf(summary,'AVERAGE TESTING CAPPA = %6.2f \n', averageCappaTest);
fprintf(output,'AVERAGE TESTING CAPPA = %6.2f \n', averageCappaTest);
fprintf(results,'AVERAGE TESTING CAPPA = %6.2f \n', averageCappaTest);

averageMCCTest = sumMCCTest(bestCIndex)/numFoldLev1;

fprintf('AVERAGE TESTING MCC = %6.2f \n', averageMCCTest);
fprintf(summary,'AVERAGE TESTING MCC = %6.2f \n', averageMCCTest);
fprintf(output,'AVERAGE TESTING MCC = %6.2f \n', averageMCCTest);
fprintf(results,'AVERAGE TESTING MCC = %6.2f \n', averageMCCTest);


averageTime = sumTime(bestCIndex)/numFoldLev1;
fprintf('AVERAGE CPU TIME = %6.2f secs \n', averageTime);
fprintf(summary,'AVERAGE CPU TIME = %6.2f secs \n', averageTime);
fprintf(output,'AVERAGE CPU TIME = %6.2f secs\n', averageTime);
fprintf(results,'AVERAGE CPU TIME = %6.2f secs\n', averageTime);

fprintf(results,'Best C  = %6.2f \n', bestCIndex);

end