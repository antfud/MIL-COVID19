function JXmax = epsX_JXmax(X,V,gamma)
%*************************************************************
% X=A=[a_1^T, a_2^T, ... , a_m^T]
% X=B=[b_1^T, b_2^T, ... , b_k^T]
% V=[v_1, v_2, ... , v_h]
% gamma=[gamma_1;gamma_2;...;gamma_h]
%*************************************************************

    [mX,nX]=size(X);
    [nV,h]=size(V);
    if (nX~=nV)
        disp 'errore sulla dimensione n';
        epsX=Inf;
        return
    end
    %*********************************************************
    
    gammaX=zeros(mX,h);
    for j=1:h
        gammaX(:,j)=gamma(j)*ones(mX,1);
    end
    %*********************************************************

    epsX=X*V-gammaX-ones(mX,h);
    % max(epsB,[],2) e' un vettore colonna contenente 
    % il massimo valore di ciascuna riga
    epsXmax=max(epsX,[],2);
    
    %*************************************************************
    JXmax=zeros(mX,h);
    for l=1:mX
       j=1;
      trovato=false;
      while (j<=h)&&(trovato==false)
%         for j=1:h
          if (epsX(l,j)==epsXmax(l))
              JXmax(l,j)=1;
              trovato=true;
          end
          j=j+1;
      end
    end
    
end

