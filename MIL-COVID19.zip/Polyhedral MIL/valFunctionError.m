%**************************************************************************
%**************************************************************************

function fV=valFunctionError(Atemp,Btemp,Vtemp,gammatemp)
    %*************************************************************
    [mtemp,ntemp]=size(Atemp);
    [ktemp,ntemp]=size(Btemp);
    [ntemp,h]=size(Vtemp);
    %*************************************************************
    % CALCOLO ERRORI SU A E B
    %*************************************************************
    epsA=epsX(Atemp,Vtemp,gammatemp,1);
    % max(epsA,[],2) e' un vettore colonna contenente 
    % il massimo valore di ciascuna riga
    epsAmax=max(epsA,[],2);
    %*************************************************************
    rhoB=epsX(Btemp,Vtemp,gammatemp,-1);
    rhoBmin=min(rhoB,[],2);
    %*************************************************************
    fVA=0.0;
    for i=1:mtemp
       if (epsAmax(i)>0.0)
           fVA=fVA+epsAmax(i);
       end
    end
    fVA=fVA/mtemp;
%    fVA=fVA;

    fVB=0.0;
    for l=1:ktemp
       if (rhoBmin(l)>0.0)
           fVB=fVB+rhoBmin(l);
       end
    end
    fVB=fVB/ktemp;
 %   fVB=fVB;

    fV=fVA+fVB;
    
end
