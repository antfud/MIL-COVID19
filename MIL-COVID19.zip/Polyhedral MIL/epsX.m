function epsX = epsX(X,V,gamma,set)
%*************************************************************
% X=A=[a_1^T, a_2^T, ... , a_m^T]
% X=B=[b_1^T, b_2^T, ... , b_k^T]
% V=[v_1, v_2, ... , v_h]
% gamma=[gamma_1;gamma_2;...;gamma_h]
%*************************************************************
% set = 1 per insieme A;
% set =-1 per insieme B;

%*************************************************************
    [mX,nX]=size(X);
    [nV,h]=size(V);
    if (nX~=nV)
        disp 'errore sulla dimensione n';
        epsX=Inf;
        return
    end
    %*************************************************************
    gammaX=zeros(mX,h);
    for j=1:h
        gammaX(:,j)=gamma(j)*ones(mX,1);
    end
    if (set==1)
        epsX=X*V-gammaX+ones(mX,h);
    else
        epsX=-X*V+gammaX+ones(mX,h);
    end

end

